<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get input values
    $engineCapacity = $_POST['engine-capacity'];
    $location = $_POST['location'];
    $ownershipType = $_POST['ownership-type'];

    // Define rates based on the website's formula (you may need to adjust these based on the actual formula)
    $engineCapacityRates = [
        '0-1400cc' => 90,
        '1401-1650cc' => 180,
        '1651-2200cc' => 330,
        '2201-3050cc' => 550,
        '3051-4100cc' => 770,
        '4100above' => 1000,
    ];
    
    $locationRates = [
        'Peninsular Malaysia' => 1.0,
        'Pulau Pangkor/Langkawi' => 0.8,
        'Sabah/Sarawak/Labuan' => 1.2,
    ];
    
    $ownershipTypeRates = [
        'Saloon Car/Individual Owned' => 1.0,
        'Saloon Car/Company Owned' => 1.2,
        'Non-Saloon Car/Individual and Company Owned' => 1.5,
    ];

    // Perform road tax calculation
    $engineCapacityTax = $engineCapacityRates[$engineCapacity];
    $locationTax = $engineCapacityTax * $locationRates[$location];
    $ownershipTypeTax = $engineCapacityTax * $ownershipTypeRates[$ownershipType];
    $totalRoadTax = $engineCapacityTax + $locationTax + $ownershipTypeTax;

    // Return the results as JSON
    header('Content-Type: application/json');
    echo json_encode([
        'engineCapacityTax' => $engineCapacityTax,
        'locationTax' => $locationTax,
        'ownershipTypeTax' => $ownershipTypeTax,
        'totalRoadTax' => $totalRoadTax,
    ]);
    exit;
}
?>
