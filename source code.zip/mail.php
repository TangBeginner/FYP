<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Required files
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// Create an instance; passing `true` enables exceptions
if (isset($_POST["send"])) {
    $mail = new PHPMailer(true);
    $recipientEmail = $_POST["email"]; // Get the email address from the form
    // Server settings
    $mail->isSMTP();                              // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';       // Set the SMTP server to send through
    $mail->SMTPAuth   = true;             // Enable SMTP authentication
    $mail->Username   = 'tsl010126@gmail.com';   // SMTP email
    $mail->Password   = 'lfqlqukairininxb';      // SMTP password
    $mail->SMTPSecure = 'ssl';            // Enable implicit SSL encryption
    $mail->Port       = 465;                                    
    // Recipients
    $senderEmail = $_POST["sender_email"]; // Get the sender's email from the hidden field
    if (!empty($senderEmail)) {
        $mail->setFrom($senderEmail, $_POST["name"]); // Sender Email and name

        if ($recipientEmail === 'all') {
            $conn = new mysqli('localhost', 'root', '', 'fyp_db');
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $sql = "SELECT email FROM user";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $mail->addBCC($row['email']); // Add each user email as a BCC recipient
                }
            }
            $conn->close();
        } else {
            $mail->addAddress($recipientEmail); // Add the selected user email
        }
        $mail->addReplyTo($senderEmail, $_POST["name"]); // Reply to sender email
        $mail->isHTML(true);               // Set email format to HTML
        $mail->Subject = $_POST["subject"];   // Email subject headings
        $mail->Body    = $_POST["message"]; // Email message

        $mail->send();

        // Save notification details in the database
        $conn = new mysqli('localhost', 'root', '', 'fyp_db');

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $name = $_POST["name"];
        $subject = $_POST["subject"];
        $message = $_POST["message"];

        if ($recipientEmail === 'all') {
            $email = 'All Users';
        } else {
            $email = $recipientEmail;
        }

        $stmt = $conn->prepare("INSERT INTO notifications (name, email, subject, message) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $subject, $message);

        if ($stmt->execute()) {
            echo "
            <script> 
            alert('Message was sent successfully and notification details saved!');
            document.location.href = 'notification.php';
            </script>
            ";
        } else {
            echo "
            <script> 
            alert('Message was sent but failed to save notification details!');
            document.location.href = 'notification.php';
            </script>
            ";
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "
        <script> 
        alert('Sender email is missing!');
        document.location.href = 'notification.php';
        </script>
        ";
    }
}
