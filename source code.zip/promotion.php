<?php
@include 'config.php';
session_start();

if (!isset($_SESSION['admin_name'])) {
   header('location:login_form.php');
   exit(); // Ensure script stops execution after redirection
}

// Handle form submission to save selected cars for promotion
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST['selected_cars'])) {
        $selectedCars = array_map('intval', $_POST['selected_cars']);
        if (count($selectedCars) > 3) {
            echo "You can only select up to three cars for promotion.";
        } else {
            // Save the selected cars in the database or any other storage mechanism
            // For example, you can update a 'promoted' field in the 'car' table
            $selectedCarsString = implode(',', $selectedCars);
            $updateQuery = "UPDATE car SET promoted = 1 WHERE car_id IN ($selectedCarsString)";

            if (mysqli_query($conn, $updateQuery)) {
                echo "Selected cars have been successfully marked for promotion.";
            } else {
                echo "Error updating record: " . mysqli_error($conn);
            }
        }
    } else {
        echo "No cars selected for promotion.";
    }
}

// Fetch cars from the database
$sql = "SELECT * FROM car";
$result = mysqli_query($conn, $sql);

// Close database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Promotion Page</title>
   <!-- Include CSS and JS files -->
</head>

<body>
   <div class="sidebar">
      <!-- Sidebar navigation -->
   </div>

   <div class="main-content">
      <h1>Promotion Page</h1>
      <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
         <h2>Select Cars for Promotion</h2>
         <?php
         if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
               // Display checkboxes for each car
               echo "<input type='checkbox' name='selected_cars[]' value='{$row['car_id']}'> {$row['specification']}<br>";
            }
         } else {
            echo "No cars found.";
         }
         ?>
         <button type="submit">Save Selection</button>
      </form>
   </div>

</body>

</html>
