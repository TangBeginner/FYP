<?php
include 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
// Assuming you have a way to get the user's ID, perhaps from the session
$userId = $_SESSION['user_id'];

// Fetch all bookings for the logged-in user
$bookingsQuery = "SELECT payments.payment_id, car.specification, car.price, model.name AS model_name, model.year AS model_year,
                  brand.name AS brand_name, meet_times.meet_datetime
                  FROM payments
                  JOIN car ON payments.car_id = car.car_id
                  JOIN model ON car.model_id = model.model_id
                  JOIN brand ON model.brand_id = brand.brand_id
                  JOIN meet_times ON payments.payment_id = meet_times.payment_id
                  WHERE payments.user_id = '$userId'";

$bookingsResult = $conn->query($bookingsQuery);

if (!$bookingsResult) {
    die("Query failed: " . $conn->error);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styleRefund.css">
    <title>My Bookings</title>
</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="">Green Star Auto Enterprise</a></div>
            <ul class="links">
                <li><a href="user_page.php">Home</a></li>
                <li><a href="aboutus.php">About</a></li>
                <li><a href="product.php">Product</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="my_booking.php"><i class="fa-solid fa-cart-shopping"></i> Order</a></li>
                <li><a href="logout.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i> Log Out</a></li>
            </ul>
            <a href="userprofile.php" class="action_btn">User</a>
        </nav>
    </header>

    <div class="bookings-container">
        <h2>My Bookings</h2>
    
        <?php if ($bookingsResult->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Car</th>
                        <th>Specification</th>
                        <th>Price</th>
                        <th>Meet Date & Time</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($booking = $bookingsResult->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $booking['brand_name'] . ' ' . $booking['model_name'] . ' (' . $booking['model_year'] . ')'; ?></td>
                            <td><?php echo $booking['specification']; ?></td>
                            <td>RM <?php echo $booking['price']; ?></td>
                            <td><?php echo $booking['meet_datetime']; ?></td>
                            <td> <a href="whatsapp://send?phone=+6011-24157828&text=I would like to request a refund for my booking with payment ID: <?php echo $paymentId; ?>" class="refund-button">
                                    Request Refund
                                </a></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No bookings found.</p>
        <?php endif; ?>
    </div>
    <script>
        //------------------------logout confirmation
        function logoutConfirmation() {
        var logoutConfirmed = confirm("Are you sure you want to log out?");
        if (logoutConfirmed) {
            // Redirect to the logout page
            window.location.replace("login.php");
        }
        }
    </script>
</body>

</html>
