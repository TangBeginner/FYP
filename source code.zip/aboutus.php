<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>about us</title>
    <link rel="stylesheet" href="style2.css">
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="">Green Star Auto Enterprise</a></div>
            <ul class="links">
            <li><a href="user_page.php">Home</a></li>
                <li><a href="aboutus.php">About</a></li>
                <li><a href="product.php">Product</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="my_booking.php">Order</a></li>
                <!-- <li><a href="user_booking.php"><i class="fa-solid fa-cart-shopping"></i> Order</a></li> -->
                <li><a href="logout.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i>
                        Log Out</a></li>
            </ul>
            <a href="userprofile.php" class="action_btn">User</a>
            <div class="toggle_btn">
                <i class="fa-solid fa-bars"></i>
            </div>

            <div class="dropdown_menu">
            <li><a href="user_page.php">Home</a></li>
                <li><a href="aboutus.php">About</a></li>
                <li><a href="">Product</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="" class="action_btn">User</a></li>
            </div>
        </nav>
    </header>

    <!--*about us-->
    <div class="splitview skewed">
        <div class="panel bottom">
            <div class="content">
                <div class="description">
                    <h1 style="color: black;">ABOUT US</h1>
                    <p style="color: black; text-align:justify">
                        Welcome to Green Star Auto Enterprise, where your automotive dreams come to
                        life! Established with a passion for delivering quality vehicles and unparalleled service, we
                        take pride in being your trusted partner on the road to exceptional driving experiences.</p>
                </div>

                <img src="img/aboutus.jpg" alt="Original">
            </div>
        </div>

        <div class="panel top">
            <div class="content">
                <div class="description">
                    <h1>OUR VISION</h1>
                    <p style="text-align:justify;">At Green Star Auto Enterprise, our vision is to redefine the
                        car-buying experience. We aim to be
                        more than just a dealership;
                        we aspire to be your automotive companion, guiding you through a seamless journey from selection
                        to ownership.</p>
                </div>

                <img src="img/aboutus1.jpg" alt="Duotone">
            </div>
        </div>

        <div class="handle"></div>
    </div>

    <!--location-->
    <div class="location">
        <h1>LOCATION</h1>
        <hr>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3973.5515581049285!2d100.48388857474217!3d5.175583194801836!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x304ab1c0c9de4c97%3A0x6d6d1b02f7a4b65e!2sGreen%20Star%20Auto%20Enterprise!5e0!3m2!1sen!2smy!4v1718941141556!5m2!1sen!2smy" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        <!-- <h3>Address: 80, Jalan Industri 2, Taman Seri Bayu, 14300 Nibong Tebal, Pulau Pinang.</h3> -->
    </div>




    <div class="containerfaq">
        <h2>Frequently Asked Questions</h2>
            <div class="accordion">
            <div class="accordion-item">
                <button id="accordion-button-1" aria-expanded="false"><span class="accordion-title">What is the phone number for Green Star Auto Enterprise?</span><span class="icon" aria-hidden="true"></span></button>
                <div class="accordion-content">
                <p>The phone number for Green Star Auto Enterprise is 012-518 2468.</p>
                </div>
            </div>
            <div class="accordion-item">
                <button id="accordion-button-2" aria-expanded="false"><span class="accordion-title">Where is Green Star Auto Enterprise located?</span><span class="icon" aria-hidden="true"></span></button>
                <div class="accordion-content">
                <p>Green Star Auto Enterprise is located at 80, Jalan Industri 2, Taman Seri Bayu, 14300 Nibong Tebal, Pulau Pinang, Malaysia, Penang.</p>
                </div>
            </div>
            <div class="accordion-item">
                <button id="accordion-button-3" aria-expanded="false"><span class="accordion-title">What days are Green Star Auto Enterprise open?</span><span class="icon" aria-hidden="true"></span></button>
                <div class="accordion-content">
                <p>Green Star Auto Enterprise is open Mon–Wed, Fri–Sat 9 AM–6 PM; Thu 9 AM–9 PM; closed Sun.</p>
                </div>
            </div>
            <div class="accordion-item">
                <button id="accordion-button-4" aria-expanded="false"><span class="accordion-title">Is there a primary contact for Green Star Auto Enterprise?</span><span class="icon" aria-hidden="true"></span></button>
                <div class="accordion-content">
                <p>You can contact Green Star Auto Enterprise by phone using number 012-518 2468.</p>
                </div>
            </div>
            </div>
        </div>

    
    <!--footer-->
    <footer class="footer-section">
        <div class="footer-container">
            <div class="footer-cta pt-5 pb-5">
                <div class="row">
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta">
                            <i class="fas fa-map-marker-alt"></i>
                            <div class="cta-text">
                                <h4>Find us</h4>
                                <span> 80, Jalan Industri 2, Taman Seri Bayu, <br>14300 Nibong Tebal, Pulau Pinang</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta1">
                            <i class="fas fa-phone"></i>
                            <div class="cta-text">
                                <h4>Call us</h4>
                                <span>012-518 2468</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta2">
                            <i class="far fa-envelope-open"></i>
                            <div class="cta-text">
                                <h4>Mail us</h4>
                                <span>Khooi197671@gmail.com</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-content pt-5 pb-5">
                <div class="row2">
                    <div class="col-xl-4 col-lg-4 mb-50">
                        <div class="footer-widget">
                            <div class="footer-logo">
                                <a href="#">Green Star Auto Enterprise</a>
                            </div>
                            <hr>
                            <div class="footer-text">
                                <p>Our comprehensive used car booking website offers a seamless experience for users to browse a wide selection of reliable pre-owned vehicles,
                                compare features and prices, read customer reviews, and conveniently book test drives or purchases, all through an intuitive and secure online platform.</p>
                            </div>
                            <div class="footer-social-icon">
                                <span>Follow us</span>
                                <a href="#"><i class="fab fa-facebook-f facebook-bg"></i></a>
                                <a href="#"><i class="fab fa-twitter twitter-bg"></i></a>
                                <a href="#"><i class="fab fa-instagram instagram-bg"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-30">
                        <div class="footer-widget">
                            <div class="footer-widget-heading">
                                <h3>Useful Links</h3>
                            </div>
                            <ul>
                                <li><a href="user_page.php">Home</a></li>
                                <li><a href="aboutus.php">About us</a></li>
                                <li><a href="product.php">Product</a></li>
                                <li><a href="gallery.php">Gallery</a></li>                                         
                                <li><a href="whatsapp://send?phone=+6011-24157828&">Contact us</a></li>
               
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-50">
                        <div class="footer-widget">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-area">
            <div class="footer-container">
                <div class="row3">
                    <div class="col-xl-6 col-lg-6 text-center text-lg-left">
                        <div class="copyright-text">
                            <p>Copyright &copy; 2024, All Right Reserved </p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 d-none d-lg-block text-right">
                        <div class="footer-menu">
                            <ul>
                                <li><a href="user_page.php">Home</a></li>
                                <li><a href="#">Terms</a></li>
                                <li><a href="#">Privacy</a></li>
                                <li><a href="#">Policy</a></li>
                                <li><a href="#">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script>
    const items = document.querySelectorAll(".accordion button");

    function toggleAccordion() {
      const itemToggle = this.getAttribute('aria-expanded');
      
      for (i = 0; i < items.length; i++) {
        items[i].setAttribute('aria-expanded', 'false');
      }
      
      if (itemToggle == 'false') {
        this.setAttribute('aria-expanded', 'true');
      }
    }

    items.forEach(item => item.addEventListener('click', toggleAccordion));
  </script>

</body>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var parent = document.querySelector('.splitview'),
            topPanel = parent.querySelector('.top'),
            handle = parent.querySelector('.handle'),
            skewHack = 0,
            delta = 0;

        // If the parent has .skewed class, set the skewHack var.
        if (parent.className.indexOf('skewed') != -1) {
            skewHack = 1000;
        }

        parent.addEventListener('mousemove', function (event) {
            // Get the delta between the mouse position and center point.
            delta = (event.clientX - window.innerWidth / 2) * 0.5;

            // Move the handle.
            handle.style.left = event.clientX + delta + 'px';

            // Adjust the top panel width.
            topPanel.style.width = event.clientX + skewHack + delta + 'px';
        });

    document.getElementById('notificationLink').addEventListener('click', function (event) {
                // Prevent the default behavior of the link (e.g., navigating to the href)
                event.preventDefault();

                // Show an alert message
                alert("Please check your email!");
            });
    });
</script>


</html>