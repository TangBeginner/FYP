<?php

@include 'config.php';

// Check if banner_id is set
if (isset($_POST['banner_id'])) {
    $banner_id = $_POST['banner_id'];

    // Delete banner from the database
    $sql = "DELETE FROM banners WHERE id = $banner_id";
    if (mysqli_query($conn, $sql)) {
        echo json_encode(['status' => 'success', 'message' => 'Banner deleted successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error deleting banner: ' . mysqli_error($conn)]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Banner ID not provided.']);
}

// Close database connection
mysqli_close($conn);
?>
