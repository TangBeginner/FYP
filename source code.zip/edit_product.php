<?php
// Include configuration and start session
@include 'config.php';
session_start();

if (!isset($_SESSION['admin_name'])) {
    header('location:login_form.php');
    exit; // Exit after redirecting
}

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the model_id from the URL parameter
$modelId = isset($_GET['model_id']) ? intval($_GET['model_id']) : 0;

// Fetch car data
$carQuery = "SELECT car.*, model.name AS model_name, model.year AS model_year, brand.name AS brand_name, body_type.type AS body_type_name
            FROM car
            JOIN model ON car.model_id = model.model_id
            JOIN brand ON model.brand_id = brand.brand_id
            JOIN body_type ON car.body_type_id = body_type.body_type_id
            WHERE model.model_id = $modelId";
$carResult = $conn->query($carQuery);

// Check if car exists
if (!$carResult || $carResult->num_rows == 0) {
    die("Invalid model_id or car not found.");
}

// Fetch car details
$carData = $carResult->fetch_assoc();

// Retrieve body types
$bodyTypesQuery = "SELECT * FROM body_type";
$bodyTypesResult = $conn->query($bodyTypesQuery);

// Initialize body types array
$bodyTypes = [];
if ($bodyTypesResult->num_rows > 0) {
    while ($row = $bodyTypesResult->fetch_assoc()) {
        $bodyTypes[] = $row;
    }
}

// Initialize the message variable
$message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $brand = $_POST['brand'];
    $model = $_POST['model'];
    $year = $_POST['year'];
    $price = $_POST['price'];
    $specification = nl2br($_POST['specification']);
    $bodyTypeId = $_POST['body_type'];
    
    $updateModelQuery = "UPDATE model SET name='$model', year='$year' WHERE model_id=$modelId";
    $conn->query($updateModelQuery);
    
    $updateCarQuery = "UPDATE car SET specification='$specification', price='$price', body_type_id='$bodyTypeId' WHERE model_id=$modelId";
    $conn->query($updateCarQuery);
    
    $images = $_FILES['image'];
    $imagePaths = [];
    
    foreach ($images['tmp_name'] as $key => $tmp_name) {
        $image = $images['name'][$key];
        $target_dir = 'uploads/';
        $target_file = $target_dir . basename($image);
        
        // Move uploaded image to the 'uploads' folder
        if (move_uploaded_file($tmp_name, $target_file)) {
            $imagePaths[] = $target_file;
            $insertImageQuery = "INSERT INTO car_image (car_id, image_path) VALUES ('$carData[car_id]', '$target_file')";
            $conn->query($insertImageQuery);
        } else {
            $message = "Sorry, there was an error uploading your files.";
        }
    }
    
    if (!empty($imagePaths)) {
        $imagePathsString = implode(',', $imagePaths);
        $updateCarQuery = "UPDATE car SET image_paths = CONCAT(image_paths, ',$imagePathsString') WHERE car_id = $carData[car_id]";
        $conn->query($updateCarQuery);
    }
    
    // Handle existing image deletion
    if (isset($_POST['delete_image'])) {
        foreach ($_POST['delete_image'] as $imagePath) {
            // Remove the image file from the server
            if (file_exists($imagePath)) {
                unlink($imagePath);
            }
            
            // Remove the image path from the car_image table
            $deleteImageQuery = "DELETE FROM car_image WHERE car_id = '$carData[car_id]' AND image_path = '$imagePath'";
            $conn->query($deleteImageQuery);
        }
        
        // Update the image_paths in the car table
        $imagePaths = array_diff(explode(',', $carData['image_paths']), $_POST['delete_image']);
        $imagePathsString = implode(',', $imagePaths);
        $updateCarQuery = "UPDATE car SET image_paths = '$imagePathsString' WHERE car_id = '$carData[car_id]'";
        $conn->query($updateCarQuery);

        // Refresh $carData['image_paths'] to reflect the new state
        $carData['image_paths'] = $imagePathsString;
    }
    
    $message = "Product updated successfully!";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link rel="stylesheet" href="styleEditProduct.css">
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>

<body>
    <div class="sidebar">
        <nav>
            <div class="logo">
                <a href="#"><span><img src="logo.jpg"></span></a>
            </div>
            <ul>
                <li><a href="admin_page.php"><i class="fa-solid fa-house"></i> Home</a></li>
                <li><a href="admin_verify.php"><i class="fa-solid fa-user"></i> User management</a></li>
                <li class="active"><a href="productmanagement.php"><i class="fa-solid fa-car"></i> Product</a></li>
                <li><a href="admin_order.php"><i class="fa-regular fa-file-lines"></i> Booking</a></li>
                <li><a href="notification.php"><i class="fa-solid fa-bell"></i> Notification</a></li>
                <li><a href="feedback.php"><i class="fa-regular fa-comment"></i> Feedback</a></li>
                <li><a href="login.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i> Log Out</a></li>
            </ul>
        </nav>
    </div>
    
    <main class="edit">
        <!-- Echo section -->
        <div class="echo-section">
            <?php
            if (!empty($message)) {
                $class = (strpos($message, 'successfully') !== false) ? 'success' : 'error';
                echo '<div class="message ' . $class . '">' . $message . '</div>';
            }
            ?>
        </div>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . "?model_id=" . $modelId; ?>" method="POST" enctype="multipart/form-data">
            <div>
                <label for="brand">Brand</label>
                <input type="text" id="brand" name="brand" class="edit" value="<?php echo $carData['brand_name']; ?>" readonly />
            </div>
            <div>
                <label for="model">Model</label>
                <input type="text" id="model" name="model" class="edit" value="<?php echo $carData['model_name']; ?>" readonly />
            </div>
            <div>
                <label for="body_type">Body Type</label>
                <select id="body_type" name="body_type" class="edit" required>
                    <?php foreach ($bodyTypes as $type) : ?>
                        <option value="<?php echo $type['body_type_id']; ?>" <?php if ($carData['body_type_id'] == $type['body_type_id']) echo 'selected'; ?>>
                            <?php echo $type['type']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="year">Year</label>
                <input type="number" id="year" name="year" min="1900" class="edit" value="<?php echo $carData['model_year']; ?>" required />
            </div>
            <div>
                <label for="price">Price</label>
                <input type="number" id="price" name="price" min="0" class="edit" value="<?php echo $carData['price']; ?>" required />
            </div>
            <div>
                <label for="specification">Specification</label>
                <textarea id="specification" name="specification" class="edit" rows="4" required><?php echo strip_tags($carData['specification']); ?></textarea>
            </div>
            <div>
                <label for="image">Upload New Images</label>
                <input type="file" id="image" name="image[]" class="edit" accept="image/*" multiple />
                <div class="existingimg">
                    <p>Existing Images <span>-select to delete<span></p>
                    <?php
                    // Display existing images with delete checkboxes
                    $existingImagePaths = explode(',', $carData['image_paths']);
                    foreach ($existingImagePaths as $imagePath) {
                        if (!empty($imagePath)) {
                            echo "<div class='image-checkbox-container'>
                                    <img src='$imagePath' alt='Car Image' class='existing-image'>
                                    <input type='checkbox' name='delete_image[]' value='$imagePath' class='image-checkbox'>
                                </div>";
                        }
                    }
                    ?>
                </div>

            </div>
            <div class="button-container">
                <button type="submit" class="update-button">Update</button>
                <button type="button" class="cancel-button" onclick="window.location.href='productmanagement.php'">Cancel</button>
            </div>
        </form>
    </main>

    <script>
        function logoutConfirmation() {
            const confirmed = confirm("Are you sure you want to log out?");
            if (!confirmed) {
                event.preventDefault();
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            const checkboxes = document.querySelectorAll('.image-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    if (this.checked) {
                        this.previousElementSibling.style.opacity = 0.5;
                    } else {
                        this.previousElementSibling.style.opacity = 1;
                    }
                });
            });
        });
    </script>
</body>

</html>
