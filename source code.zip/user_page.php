<?php
@include 'config.php';

// Start with a base query to fetch cars
$carsQuery = "SELECT car.*, model.name as model_name, model.year as model_year, brand.name as brand_name, GROUP_CONCAT(car_image.image_path) as image_paths
              FROM car
              JOIN model ON car.model_id = model.model_id
              JOIN brand ON model.brand_id = brand.brand_id
              JOIN car_image ON car.car_id = car_image.car_id";

// Start with an empty array to store filter conditions
$whereConditions = [];

// Check if search query is provided
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']);
    // Add search conditions to the WHERE clause
    $whereConditions[] = "(brand.name LIKE '%$search%' OR model.name LIKE '%$search%' OR model.year = '$search' OR car.price = '$search')";
}

// Combine all conditions into a single WHERE clause
if (!empty($whereConditions)) {
    $carsQuery .= " WHERE " . implode(" AND ", $whereConditions);
}

if (isset($_GET['body_type']) && !empty($_GET['body_type'])) {
    $bodyTypeFilter = $conn->real_escape_string($_GET['body_type']);
    $whereConditions[] = "car.body_type_id = '$bodyTypeFilter'";
}

// Group by car ID to avoid duplicate rows
$carsQuery .= " GROUP BY car.car_id";

// Execute the query
$result = $conn->query($carsQuery);

if (!$result) {
    die("Query failed: " . $conn->error);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>homepage</title>
    <link rel="stylesheet" href="style1.css">
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
    
</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="">Green Star Auto Enterprise</a></div>
            <ul class="links">
                <li><a href="user_page.php">Home</a></li>
                <li><a href="aboutus.php">About</a></li>
                <li><a href="product.php">Product</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="my_booking.php">Order</a></li>
                <!-- <li><a href="user_booking.php"><i class="fa-solid fa-cart-shopping"></i> Order</a></li> -->
                <li><a href="logout.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i>
                        Log Out</a></li>
            </ul>
            <a href="userprofile.php" class="action_btn">User</a>
            <div class="toggle_btn">
                <i class="fa-solid fa-bars"></i>
            </div>

            <div class="dropdown_menu">
                <li><a href="">Home</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Product</a></li>
                <li><a href="">Gallery</a></li>
                <li><a href="">Login</a></li>
                <li><a href="" class="action_btn">User</a></li>
            </div>
        </nav>
    </header>

  <!-- Banner -->
  <div class="slider">
        <div class="list">
            <?php
            @include 'config.php';
            // Fetch banners from the database
            $sql = "SELECT * FROM banners";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<div class='item'><img src='{$row['image']}' alt='Banner Image'></div>";
                }
            } else {
                echo "<div class='item'><img src='default_banner.jpg' alt='Default Banner'></div>"; // Default banner if no banners are available
            }

            // Close database connection
            mysqli_close($conn);
            ?>
        </div>

        <!-- Buttons -->
        <div class="buttons">
            <button id="prev"><</button>
            <button id="next">></button>
        </div>
        <!-- Dots -->
        <ul class="dots">
            <!-- Dots will be added dynamically via JavaScript -->
        </ul>
    </div>


    <div class="carbrand">
            <h1>Browse New Car </h1> 
            
            <form method="GET" action="product.php">
                <div class="search-bar">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input type="text" name="search" placeholder="Search for car by Brand, Body Type, Year...">
                </div>
            </form>
            <div class="horizontal-containers">
                <div class="local-container">
                <a href="product.php?search[]=proton&search[]=peroduo">
                        <img src="img/localmyvi.jpg" alt="Local Image">
                        <span class="tooltip">LOCAL</span>
                    </a>
                </div>
                <div class="japan-container">
                <a href="product.php?search[]=toyota&search[]=honda&search[]=mitsubishi&search[]=lexus">
                        <img src="img/japanvios.jpeg" alt="Japan Image">
                        <span class="tooltip">JAPAN</span>
                    </a>
                </div>
                <div class="korea-container">
                <a href="product.php?search[]=kia&search[]=hyundai">
                        <img src="img/koreacerato.jpeg" alt="Korea Image">
                        <span class="tooltip">KOREA</span>
                    </a>
                </div>
            </div>
            <!-- <h5>Please scroll to explore more.</h5> -->
            <p><a href="product.php" class="button-seemore">See More ></a></p>
    </div>
    <!-- Car Brands -->
    <div class="car-brands-wrap">
        <img src="img/back.png" id="backBtn">
        <div class="car-brands">
            <div>
                <span><a href="product.php?brand=honda"><img src="img/honda.png"><figcaption>Honda</figcaption></a></span>
                <span><a href="product.php?brand=toyota"><img src="img/toyota.png"><figcaption>toyota</figcaption></a></span>
                <span><a href="product.php?brand=lexus"><img src="img/lexus.png"><figcaption>lexus</figcaption></a></span>
                <span><a href="product.php?brand=nissan"><img src="img/nissan.png"><figcaption>nissan</figcaption></a></span>
                <span><a href="product.php?brand=kia"><img src="img/kia.png"><figcaption>kia</figcaption></a></span>
            </div>
            <div>
                <span><a href="product.php?brand=proton"><img src="img/proton.png"><figcaption>proton</figcaption></a></span>
                <span><a href="product.php?brand=peroduo"><img src="img/perodua.png"><figcaption>perodua</figcaption></a></span>
                <span><a href="product.php?brand=mazda"><img src="img/mazda.png"><figcaption>mazda</figcaption></a></span>
                <span><a href="product.php?brand=volkswagen"><img src="img/volkswagen.png"><figcaption>volkswagen</figcaption></a></span>
                <span><a href="product.php?brand=subaru"><img src="img/subaru.png"><figcaption>subaru</figcaption></a></span>
            </div>
            <div>
                <span><a href="product.php?brand=mercedes"><img src="img/mercedes.png"><figcaption>mercedes</figcaption></a></span>
                <span><a href="product.php?brand=bmw"><img src="img/bmw.png"><figcaption>bmw</figcaption></a></span>
                <span><a href="product.php?brand=audi"><img src="img/audi.png"><figcaption>audi</figcaption></a></span>
                <span><a href="product.php?brand=citroen"><img src="img/citroen.png"><figcaption>citroen</figcaption></a></span>
                <span><a href="product.php?brand=peugeot"><img src="img/peugeot.png"><figcaption>peugeot</figcaption></a></span>
            </div>
            <div>
                <span><a href="product.php?brand=hyundai"><img src="img/hyundai.png"><figcaption>hyundai</figcaption></a></span>
                <span><a href="product.php?brand=volvo"><img src="img/volvo.png"><figcaption>volvo</figcaption></a></span>
                <span><a href="product.php?brand=ford"><img src="img/ford.png"><figcaption>ford</figcaption></a></span>
                <span><a href="product.php?brand=suzuki"><img src="img/suzuki.png"><figcaption>suzuki</figcaption></a></span>
                <span><a href="product.php?brand=mitsubishi"><img src="img/mitsubishi.png"><figcaption>mitsubishi</figcaption></a></span>
            </div>
        </div>
        <img src="img/next.png" id="nextBtn">
    </div>

    <div class="body-containers-top">
            <h1>Search for lifestyle</h1>
            <h2><a href="product.php">View more ></a></h2>
            <div class="body-containers">
                <div class="suv-container">
                    <a href="product.php?search[]=SUV">
                        <img src="img/suv.png" alt="SUV">
                    </a>
                    <p>Family</p>
                </div>
                <div class="hatchback-container">
                    <a href="product.php?search[]=Hatchback">
                        <img src="img/hatchback.png" alt="hatchback">
                    </a>
                    <p>Hatchback</p>
                </div>
                <div class="sedan-container">
                    <a href="product.php?search[]=Sedan">
                        <img src="img/sedan.png" alt="sedan">
                    </a>
                    <p>Sedan</p>
                </div>
                <div class="mpv-container">
                    <a href="product.php?search[]=truck">
                        <img src="img/mpv.png" alt="MPV">
                    </a>
                    <p>Offroad 4x4</p>
                </div>
            </div>
            <hr>
        </div>
    
        <div class="ev-containers-top">
        <h1>Discover EV models</h1>
        <h2><a href ="product.php?search[]=Electric Vehicle(EV)">View more EV car ></a></h2>
            <div class="ev-containers">
                <div class="tesla-container">
                    <a href="product.php?search[]=tesla&search[]=tesla">
                        <img src="img/teslalogo.jpg" alt="tesla" onmouseover="this.src='img/tesla_hover.png'" onmouseout="this.src='img/teslalogo.jpg'">
                    </a>
                </div>
                <div class="byd-container">
                    <a href="product.php?search[]=byd&search[]=byd">
                        <img src="img/byd.jpg" alt="BYD" onmouseover="this.src='img/byd_hover.png'" onmouseout="this.src='img/byd.jpg'">
                    </a>
                </div>
                <div class="ora-container">
                    <a href="product.php?search[]=ora&search[]=ora">
                        <img src="img/ora.jpg" alt="Ora" onmouseover="this.src='img/ora_hover.png'" onmouseout="this.src='img/ora.jpg'">
                    </a>
                </div>
                <div class="volvo-container">
                    <a href="product.php?search[]=volvo&search[]=volvo">
                        <img src="img/volvoev.jpg" alt="Volvo" onmouseover="this.src='img/volvo_hover.png'" onmouseout="this.src='img/volvoev.jpg'">
                    </a>
                </div>
            </div>
            <hr>
        </div>

     


    <!-- car purchase ------------------------->
    <div class="car-purchase">
        <h1>Car Purchase Process</h1>
        <hr>
    </div>
    <div class="containerbox">
    <div class="processcard">
      <div class="box">
        <div class="percent">
          <svg>
            <circle cx="70" cy="70" r="70"></circle>
            <circle cx="70" cy="70" r="70"></circle>
          </svg>
          <div class="number">
            <h2>Step 1<span></span></h2>
          </div>
        </div>
        <h2 class="text">Book Online<br>
        </h2>
      </div>
      <p>Select and reserve their desired car on the website.</p>
    </div>

    <div class="processcard">
      <div class="box">
        <div class="percent">
          <svg>
            <circle cx="70" cy="70" r="70"></circle>
            <circle cx="70" cy="70" r="70"></circle>
          </svg>
          <div class="number">
            <h2>Step 2<span></span></h2>
          </div>
        </div>
        <h2 class="text">Test Drive</h2>
      </div>
      <p>Schedule and experience a test drive to evaluate the chosen car's performance firsthand.</p>
    </div>

    <div class="processcard">
      <div class="box">
        <div class="percent">
          <svg>
            <circle cx="70" cy="70" r="70"></circle>
            <circle cx="70" cy="70" r="70"></circle>
          </svg>
          <div class="number">
            <h2>Step 3<span></span></h2>
          </div>
        </div>
        <h2 class="text">Make Payment</h2>
      </div>
      <p>Complete the purchase transaction.</p>
    </div>

    <div class="processcard">
      <div class="box">
        <div class="percent">
          <svg>
            <circle cx="70" cy="70" r="70"></circle>
            <circle cx="70" cy="70" r="70"></circle>
          </svg>
          <div class="number">
            <h2>Step 4<span></span></h2>
          </div>
        </div>
        <h2 class="text">Pick Up</h2>
      </div>
      <p>Customers collect their purchased car from the dealership after finalizing paperwork, receiving necessary guidance before driving off.</p>
    </div>
  </div>



    <!-- Loan Calculator -->
     <div class="calculator">
        <div class="financing">
                <h1>FINANCING</h1>
                <h5>Find out if you can afford your dream car</h5>
                <h4><a href="product.php">View your affordable car >    </a> </h4>
            </div>
        <div class="content-calculator">
        
            <div class="loan-calculator">
                <h2>Loan Calculator</h2>
                <form id="loan-form">
                    <label for="vehicle-price">Vehicle Price:</label>
                    <input type="number" id="vehicle-price" required placeholder="Enter Price">

                    <label for="deposit">Deposit:</label>
                    <input type="number" id="deposit" required placeholder="Enter Amount of Deposit">

                    <label for="bank-rate">Bank Rate:</label>
                    <input type="number" id="bank-rate" required placeholder="Enter Bank Rate">

                    <label for="loan-period">Loan Period (months):</label>
                    <input type="number" id="loan-period" required placeholder="Enter Loan Period(month)">

                    <label for="monthly-installment">Estimated Monthly Installment:</label>
                    <input type="text" id="monthly-installment" readonly>

                    <button type="button" onclick="calculateLoan()">Calculate</button>
                </form>
            </div>

            <!-- Road Tax Calculator -->
            <form id="road-tax-form" action="user_page.php" method="post">
            <h2>Road Tax Calculator</h2>
                <label for="engine-capacity">Engine Capacity:</label>
                <select id="engine-capacity" name="engine-capacity" required>
                    <option value="0-1400cc">0-1400cc</option>
                    <option value="1401-1650cc">1401-1650cc</option>
                    <option value="1651-2200cc">1651-2200cc</option>
                    <option value="2201-3050cc">2201-3050cc</option>
                    <option value="3051-4100cc">3051-4100cc</option>
                    <option value="4100above">4100cc and above</option>
                </select>
                <br>
                <label for="location">Location:</label>
                <select id="location" name="location" required>
                    <option value="Peninsular Malaysia">Peninsular Malaysia</option>
                    <option value="Pulau Pangkor/Langkawi">Pulau Pangkor/Langkawi</option>
                    <option value="Sabah/Sarawak/Labuan">Sabah/Sarawak/Labuan</option>
                </select>
                <br>
                <label for="ownership-type">Ownership Type:</label>
                <select id="ownership-type" name="ownership-type" required>
                    <option value="Saloon Car/Individual Owned">Saloon Car/Individual Owned</option>
                    <option value="Saloon Car/Company Owned">Saloon Car/Company Owned</option>
                    <option value="Non-Saloon Car/Individual and Company Owned">Non-Saloon Car/Individual and Company Owned
                    </option>
                </select>
                <br>
                <label for="totalRoadTax">Total Road Tax:</label>
                <input type="text" id="totalRoadTax" readonly>
                <br>
                <button type="button" onclick="calculateRoadTax()">Calculate</button>
                <p><strong>*Saloon&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</strong>: Sedan / Hatchback / Coupe / Wagon / Convertible
                <br><strong>*Non Saloon&nbsp&nbsp&nbsp&nbsp</strong>: MPV / SUV / Pick-up / Commercial</p>
            </form>

            <h6>* Please use this calculator as a guide only. All interest rates, amounts and terms are based on a personal simulation by you and your assumptions of same. 
                <br>The results in every case are approximate.</h6>
        </div>
        </div>


        <section class="section-c">
      <div class="gallery">
        <a href="product.php?brand=mercedes" class="big"
          ><img src="img/cedric-streit-H7qMwOxf6Z8-unsplash.jpg" alt="mercedes"
        /></a>
        <a href="product.php?brand=bmw" class="big"
          ><img src="img/leon-seibert-1RiyAwNIiew-unsplash.jpg" alt=""
        /></a>
        <a href="product.php?brand=volkswagen" class="big"
          ><img src="img/isak-pettersson-6a0R0SYIafY-unsplash.jpg" alt=""
        /></a>
        <a href="product.php?brand=ford" class="big"
          ><img src="img/demian-tejeda-benitez-71LzirTPurQ-unsplash.jpg" alt=""
        /></a>
        <a href="product.php?brand=subaru" class="big">
          <img src="img/patrik-storm-alstra-pictures-ayEZF-gBUDs-unsplash.jpg" alt=""
        /></a>
        <a href="product.php?brand=audi" class="big"
          ><img src="img/martin-katler-OBkvEbBBIkM-unsplash.jpg" alt=""
        /></a>
      </div>
    </section>


    <div class="tradein">
    <img src="img/tradein.png">
    <div class="tradeinfo">
        <h1>Trade in for a new ride to enjoy high price rebate.</h1>
        <h3>Start by checking your car’s estimated value here and book an appointment. <br>We’ll help with the rest.</h3>
        <h5><a href="whatsapp://send?phone=+6011-24157828&text=I'm interested in estimating my car's price"><i class="fa-solid fa-arrow-right-long"></i> Estimate Your Car’s Price</a></h5>
    </div>
</div>





    <!--footer-->
    <footer class="footer-section">
        <div class="footer-container">
            <div class="footer-cta pt-5 pb-5">
                <div class="row">
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta">
                            <i class="fas fa-map-marker-alt"></i>
                            <div class="cta-text">
                                <h4>Find us</h4>
                                <span> 80, Jalan Industri 2, Taman Seri Bayu, <br>14300 Nibong Tebal, Pulau Pinang</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta1">
                            <i class="fas fa-phone"></i>
                            <div class="cta-text">
                                <h4>Call us</h4>
                                <span>012-518 2468</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta2">
                            <i class="far fa-envelope-open"></i>
                            <div class="cta-text">
                                <h4>Mail us</h4>
                                <span>Khooi197671@gmail.com</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-content pt-5 pb-5">
                <div class="row2">
                    <div class="col-xl-4 col-lg-4 mb-50">
                        <div class="footer-widget">
                            <div class="footer-logo">
                                <a href="#">Green Star Auto Enterprise</a>
                            </div>
                            <hr>
                            <div class="footer-text">
                                <p>Our comprehensive used car booking website offers a seamless experience for users to browse a wide selection of reliable pre-owned vehicles,
                                compare features and prices, read customer reviews, and conveniently book test drives or purchases, all through an intuitive and secure online platform.</p>
                            </div>
                            <div class="footer-social-icon">
                                <span>Follow us</span>
                                <a href="#"><i class="fab fa-facebook-f facebook-bg"></i></a>
                                <a href="#"><i class="fab fa-twitter twitter-bg"></i></a>
                                <a href="#"><i class="fab fa-instagram instagram-bg"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-30">
                        <div class="footer-widget">
                            <div class="footer-widget-heading">
                                <h3>Useful Links</h3>
                            </div>
                            <ul>
                                <li><a href="user_page.php">Home</a></li>
                                <li><a href="aboutus.php">About us</a></li>
                                <li><a href="product.php">Product</a></li>
                                <li><a href="gallery.php">Gallery</a></li>                                         
                                <li><a href="whatsapp://send?phone=+6011-24157828&text=I'm interested in estimating my car's price">Contact us</a></li>
               
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-50">
                        <div class="footer-widget">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-area">
            <div class="footer-container">
                <div class="row3">
                    <div class="col-xl-6 col-lg-6 text-center text-lg-left">
                        <div class="copyright-text">
                            <p>Copyright &copy; 2024, All Right Reserved </p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 d-none d-lg-block text-right">
                        <div class="footer-menu">
                            <ul>
                                <li><a href="#">Home</a></li>
                                <li><a href="#">Terms</a></li>
                                <li><a href="#">Privacy</a></li>
                                <li><a href="#">Policy</a></li>
                                <li><a href="#">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
<script>
    
//  document.addEventListener('DOMContentLoaded', function () {
    //loan-calculator---------------------------------------
    function calculateLoan() {
        // Get input values
        const vehiclePrice = parseFloat(document.getElementById('vehicle-price').value);
        const deposit = parseFloat(document.getElementById('deposit').value);
        const bankRate = parseFloat(document.getElementById('bank-rate').value);
        const loanPeriod = parseFloat(document.getElementById('loan-period').value);

        // Perform loan calculation
        const loanAmount = vehiclePrice - deposit;
        const monthlyInterestRate = (bankRate / 100) / 12;
        const totalPayments = loanPeriod;
        const calculation = (Math.pow(1 + monthlyInterestRate, totalPayments) - 1) / (monthlyInterestRate * Math.pow(1 + monthlyInterestRate, totalPayments));
        const monthlyInstallment = loanAmount / calculation;

        // Display the result
        document.getElementById('monthly-installment').value = `RM ${monthlyInstallment.toFixed(2)}`;
    }


    function calculateRoadTax() {
        // Get input values
        const engineCapacity = document.getElementById('engine-capacity').value;
        const location = document.getElementById('location').value;
        const ownershipType = document.getElementById('ownership-type').value;
    // Define rates based on the website's formula
    const engineCapacityRates = {
        '0-1400cc': 90,
        '1401-1650cc': 180,
        '1651-2200cc': 330,
        '2201-3050cc': 550,
        '3051-4100cc': 770,
        '4100above': 1000,
    };

    const locationRates = {
        'Peninsular Malaysia': 1.0,
        'Pulau Pangkor/Langkawi': 0.8,
        'Sabah/Sarawak/Labuan': 1.2,
    };

    const ownershipTypeRates = {
        'Saloon Car/Individual Owned': 1.0,
        'Saloon Car/Company Owned': 1.2,
        'Non-Saloon Car/Individual and Company Owned': 1.5,
    };

    // Perform road tax calculation
    const engineCapacityTax = engineCapacityRates[engineCapacity] || 0;
    const locationTax = locationRates[location] || 0;
    const ownershipTypeTax = ownershipTypeRates[ownershipType] || 0;
    const totalRoadTax = engineCapacityTax * locationTax * ownershipTypeTax;

    // Display the calculated road tax values
    document.getElementById('totalRoadTax').value = `RM ${totalRoadTax.toFixed(2)}`;
}

    //banner
    let slider = document.querySelector('.slider .list');
    let items = document.querySelectorAll('.slider .list .item');
    let next = document.getElementById('next');
    let prev = document.getElementById('prev');
    let dots = document.querySelectorAll('.slider .dots li');

    let lengthItems = items.length - 1;
    let active = 0;
    next.onclick = function () {
        active = active + 1 <= lengthItems ? active + 1 : 0;
        reloadSlider();
    }
    prev.onclick = function () {
        active = active - 1 >= 0 ? active - 1 : lengthItems;
        reloadSlider();
    }
    let refreshInterval = setInterval(() => { next.click() }, 5000);

    function reloadSlider() {
        slider.style.left = -items[active].offsetLeft + 'px';
        let last_active_dot = document.querySelector('.slider .dots li.active');
        last_active_dot.classList.remove('active');
        dots[active].classList.add('active');

        clearInterval(refreshInterval);
        refreshInterval = setInterval(() => { next.click() }, 5000);

    }

    dots.forEach((li, key) => {
        li.addEventListener('click', () => {
            active = key;
            reloadSlider();
        })
    })
    window.onresize = function (event) {
        reloadSlider();
    };



    //car-brands
    let scrollContainer = document.querySelector('.car-brands');
    let backBtn = document.getElementById("backBtn");
    let nextBtn = document.getElementById("nextBtn");

    scrollContainer.addEventListener("wheel", (evt) => {
        evt.preventDefault();
        scrollContainer.scrollLeft += evt.deltaY;
        scrollContainer.style.scrollBehavior = "auto";
    });

    nextBtn.addEventListener("click", () => {
        scrollContainer.style.scrollBehavior = "smooth";
        scrollContainer.scrollLeft += 1200;
    })

    backBtn.addEventListener("click", () => {
        scrollContainer.style.scrollBehavior = "smooth";
        scrollContainer.scrollLeft -= 1200;
    })

    //------------------------logout confirmation
    function logoutConfirmation() {
    var logoutConfirmed = confirm("Are you sure you want to log out?");
    if (logoutConfirmed) {
        // Redirect to the logout page
        window.location.replace("login.php");
    }
    }

    document.getElementById('notificationLink').addEventListener('click', function (event) {
                // Prevent the default behavior of the link (e.g., navigating to the href)
                event.preventDefault();

                // Show an alert message
                alert("Please check your email!");
            });

    $(function() {
        const $gallery = $('.gallery a').simpleLightbox();
      });
</script>

</html>