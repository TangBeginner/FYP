<?php
include 'config.php';
session_start();

// Check if the payment_id is provided in the URL
if (isset($_GET['payment_id']) && !empty($_GET['payment_id'])) {
    $paymentId = $conn->real_escape_string($_GET['payment_id']);

    // Fetch details of the payment and the booked car
    $paymentDetailsQuery = "SELECT payments.*, car.specification, car.price, model.name AS model_name, model.year AS model_year,
                            brand.name AS brand_name, meet_times.meet_datetime
                            FROM payments
                            JOIN car ON payments.car_id = car.car_id
                            JOIN model ON car.model_id = model.model_id
                            JOIN brand ON model.brand_id = brand.brand_id
                            JOIN meet_times ON payments.payment_id = meet_times.payment_id
                            WHERE payments.payment_id = '$paymentId'";

    $paymentDetailsResult = $conn->query($paymentDetailsQuery);

    if ($paymentDetailsResult->num_rows > 0) {
        $paymentDetails = $paymentDetailsResult->fetch_assoc();
    } else {
        die("Payment details not found");
    }
} else {
    die("Payment ID not provided");
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Refund Request</title>
    <link rel="stylesheet" href="styleRefund.css">
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="">Green Star Auto Enterprise</a></div>
            <ul class="links">
                <li><a href="user_page.php">Home</a></li>
                <li><a href="aboutus.php">About</a></li>
                <li><a href="product.php">Product</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="user_booking.php"><i class="fa-solid fa-cart-shopping"></i> Order</a></li>
                <li><a href="login.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i>
                        Log Out</a></li>
            </ul>
            <a href="userprofile.php" class="action_btn">User</a>
            <div class="toggle_btn">
                <i class="fa-solid fa-bars"></i>
            </div>

            <div class="dropdown_menu">
                <li><a href="user_page.php">Home</a></li>
                <li><a href="aboutus.php">About</a></li>
                <li><a href="product.php">Product</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="login.php" class="action_btn">Login</a></li>
                <li><a href="userprofile.php" class="action_btn">User</a></li>
            </div>
        </nav>
    </header>

    <div class="refund-container">
        <h2>Booking Details</h2>
        <hr>
        <p>Car: <?php echo $paymentDetails['brand_name'] . ' ' . $paymentDetails['model_name'] . ' (' . $paymentDetails['model_year'] . ')'; ?></p>
        <p>Specification: <?php echo $paymentDetails['specification']; ?></p>
        <p>Price: RM <?php echo $paymentDetails['price']; ?></p>
        <p>Contact Name: <?php echo $paymentDetails['contact_name']; ?></p>
        <p>Contact Phone: <?php echo $paymentDetails['contact_phone']; ?></p>
        <p>Meet Date and Time: <?php echo $paymentDetails['meet_datetime']; ?></p>
        <p>Payment Amount: RM <?php echo $paymentDetails['payment_amount']; ?></p>
        
        <a href="whatsapp://send?phone=+6011-24157828&text=I would like to request a refund for my booking with payment ID: <?php echo $paymentId; ?>" class="refund-button">
            Request Refund via WhatsApp
        </a>

    </div>
</body>

</html>
