<?php
@include 'config.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Handle form submission
    $user_name = $_POST["user_name"];
    $comment = $_POST["comment"];

    // Get the user_id based on the user_name (You may want to implement a better way to identify the user)
    $result = $conn->query("SELECT id FROM user WHERE name = '$user_name'");

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $user_id = $row['id'];

        // Handle file upload
        $target_dir = "uploads/";
        $photo_path = $target_dir . basename($_FILES["photo"]["name"]);

        if (move_uploaded_file($_FILES["photo"]["tmp_name"], $photo_path)) {
            // Use prepared statements to prevent SQL injection
            $stmt = $conn->prepare("INSERT INTO feedback (user_id, comment, photo_path) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $user_id, $comment, $photo_path);

            // Execute the statement
            if ($stmt->execute()) {
                // Redirect back to gallery.php with a success parameter
                header("Location: gallery.php?feedback=success");
                exit(); // Exit the script after the redirection
            } else {
                echo "Error: " . $stmt->error;
            }

            // Close the statement
            $stmt->close();
        } else {
            echo "Error uploading photo.";
        }
    } else {
        echo "User not found.";
    }
}

$conn->close();
?>
