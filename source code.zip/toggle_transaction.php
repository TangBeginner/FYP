<?php
// Include database connection
include 'config.php';

// Check if payment_id and action are set
if (isset($_POST['payment_id'], $_POST['action']) && is_numeric($_POST['payment_id'])) {
    $paymentId = $_POST['payment_id'];
    $action = $_POST['action'];

    // Toggle transaction status between 'done' and 'pending'
    if ($action === 'confirm') {
        $updateQuery = "UPDATE payments SET transaction_status = 'done' WHERE payment_id = $paymentId";
    } elseif ($action === 'undo') {
        $updateQuery = "UPDATE payments SET transaction_status = 'pending' WHERE payment_id = $paymentId";
    }

    if ($conn->query($updateQuery) === TRUE) {
        echo 'Transaction status updated successfully!';
    } else {
        echo 'Error updating transaction status: ' . $conn->error;
    }
}
?>
