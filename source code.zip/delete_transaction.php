<?php
include 'config.php';
session_start();

// Check if the user is logged in as an admin (you may need to adjust this based on your authentication mechanism)
// Uncomment and adjust the following lines as needed
// if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
//     header("Location: login.php"); // Redirect to the login page if not logged in as admin
//     exit();
// }

// Get the payment ID from the POST request
$paymentId = isset($_POST['payment_id']) ? $_POST['payment_id'] : '';

if ($paymentId) {
    // Use prepared statements to prevent SQL injection
    $deleteQuery = "DELETE FROM payments WHERE payment_id = ?";
    $stmt = $conn->prepare($deleteQuery);
    $stmt->bind_param("i", $paymentId);

    if ($stmt->execute()) {
        echo "Payment record deleted successfully.";
    } else {
        error_log("Error deleting payment record: " . $stmt->error);
        echo "Error deleting payment record: " . $stmt->error;
    }

    $stmt->close();
} else {
    error_log("Invalid payment ID.");
    echo "Invalid payment ID.";
}

$conn->close();
?>
