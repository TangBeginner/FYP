<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notification Page</title>
    <link rel="stylesheet" href="styleNotice.css"> <!-- Add your custom CSS file link -->
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  

</head>

<body>
    <div class="sidebar">
        <nav>
            <div class="logo">
                <a href="#"><span><img src="logo.jpg"></span></a>
            </div>
            <ul>
                <li><a href="admin_page.php"><i class="fa-solid fa-house"></i> Home</a></li>
                <li><a href="admin_verify.php"><i class="fa-solid fa-user"></i> User management</a></li>
                <li><a href="productmanagement.php"><i class="fa-solid fa-car"></i> Product</a></li>
                <li><a href="admin_order.php"><i class="fa-regular fa-file-lines"></i> Booking</a></li>
                <li class="active"><a href="notification.php"><i class="fa-solid fa-bell"></i> Notification</a></li>
                <li><a href="feedback.php"><i class="fa-regular fa-comment"></i> Feedback</a></li>
                <li><a href="login.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i>
                        Log Out</a></li>
            </ul>
        </nav>
    </div>

    <div class="main-content">

        <form id="contact" action="mail.php" method="post">

        <h1>Notification</h1>
            <div class ="selection">
                <fieldset>
                    <input placeholder="Name" name="name" type="text" tabindex="1" autofocus>
                </fieldset>
                <fieldset>
                    <select name="email" tabindex="2" autofocus>
                        <option value="all">All Users</option>
                        <?php
                        // Connect to the database
                        $conn = new mysqli('localhost', 'root', '', 'fyp_db');

                        // Check connection
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        // Fetch user emails
                        $sql = "SELECT email FROM user";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row['email'] . "'>" . $row['email'] . "</option>";
                            }
                        }

                        $conn->close();
                        ?>
                    </select>
                </fieldset>
            </div>
            <fieldset>
                <input placeholder="Type subject line" type="text1" name="subject" tabindex="4">
            </fieldset>
            <fieldset>
                <textarea name="message" placeholder="Type Message Details Here..." tabindex="5"></textarea>
            </fieldset>

            <fieldset>
                <input type="hidden" name="sender_email" value="tsl010126@gmail.com"> 
                <button type="submit" name="send" id="contact-submit">Submit Now</button>
            </fieldset>
        </form>
    </div>

    <script>
        //------------------------logout confirmation
        function logoutConfirmation() {
            var logoutConfirmed = confirm("Are you sure you want to log out?");
            if (logoutConfirmed) {
                // Redirect to the logout page
                window.location.href = "login.php";
            }
        }
    </script>

</body>

</html>