<?php
// Check if image path is received
if(isset($_POST['imgPath'])){
    $imgPath = $_POST['imgPath'];
    
    // Check if the file exists
    if(file_exists($imgPath)){
        // Attempt to delete the file
        if(unlink($imgPath)){
            // Image deleted successfully, now remove the image path from the database
            include 'config.php'; // Include the database configuration file
            
            // Prepare and execute the database query to remove the image path
            $updateQuery = "UPDATE car SET image_paths = REPLACE(image_paths, '$imgPath,', '') WHERE FIND_IN_SET('$imgPath', image_paths)";
            if ($conn->query($updateQuery) === TRUE) {
                echo "Image deleted successfully and database updated.";
            } else {
                echo "Error updating database: " . $conn->error;
            }
            
            // Close the database connection
            $conn->close();
        } else {
            // Failed to delete the image
            echo "Failed to delete the image.";
        }
    } else {
        // File does not exist
        echo "Image does not exist.";
    }
} else {
    // No image path received
    echo "No image path received.";
}
?>
