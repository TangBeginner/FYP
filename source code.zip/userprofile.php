<?php
@include 'config.php';

session_start();

// Initialize variables
$success_message = '';
$error_message = '';

// Check if the user is logged in
if (!isset($_SESSION['user_name'])) {
    header('location: login.php');
    exit();
}

$user_name = $_SESSION['user_name'];

// Fetch user details from the database
$select_user = "SELECT * FROM user WHERE name = '$user_name'";
$result_user = mysqli_query($conn, $select_user);

if ($result_user && mysqli_num_rows($result_user) > 0) {
    $user_data = mysqli_fetch_assoc($result_user);

    // Handle form submission for updating user information
    if (isset($_POST['update'])) {
        $new_name = mysqli_real_escape_string($conn, $_POST['new_name']);
        $new_phone = mysqli_real_escape_string($conn, $_POST['new_phone']) ? mysqli_real_escape_string($conn, $_POST['new_phone']) : $user_data['phone'];

        // Handle password update
        $new_password = $user_data['password']; // Default to current password if not updating
        if (!empty($_POST['new_password'])) {
            $password = $_POST['new_password'];
            if (preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $password)) {
                $new_password = password_hash($password, PASSWORD_DEFAULT);
            } else {
                $error_message = "Password must include uppercase, lowercase, number, special character, and be at least 8 characters long.";
            }
        }

        // Handle file upload
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["profile_picture"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $uploadOk = 1;
        $photo_path = $user_data['photo']; // Default to current photo

        if (!empty($_FILES["profile_picture"]["tmp_name"])) {
            // Check if image file is an actual image or fake image
            $check = getimagesize($_FILES["profile_picture"]["tmp_name"]);
            if ($check !== false) {
                $uploadOk = 1;
            } else {
                $error_message = "File is not an image.";
                $uploadOk = 0;
            }

            // Check file size
            if ($_FILES["profile_picture"]["size"] > 2000000) { // 2MB limit
                $error_message = "Sorry, your file is too large.";
                $uploadOk = 0;
            }

            // Allow certain file formats
            if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                $error_message = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }

            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 1) {
                if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file)) {
                    $photo_path = $target_file;
                } else {
                    $error_message = "Sorry, there was an error uploading your file.";
                }
            }
        }

        // Update user information in the database
        if (empty($error_message)) {
            $update_query = "UPDATE user SET name = '$new_name', password = '$new_password', phone = '$new_phone', photo = '$photo_path' WHERE name = '$user_name'";
            if (mysqli_query($conn, $update_query)) {
                // Update successful, set success message
                $success_message = 'Profile updated successfully!';

                // Fetch updated user details from the database
                $select_updated_user = "SELECT * FROM user WHERE name = '$new_name'";
                $result_updated_user = mysqli_query($conn, $select_updated_user);

                if ($result_updated_user && mysqli_num_rows($result_updated_user) > 0) {
                    $user_data = mysqli_fetch_assoc($result_updated_user);
                    $_SESSION['user_name'] = $new_name; // update session with new username
                }
            } else {
                // Update failed, handle the error if needed
                $error_message = 'Error updating profile: ' . mysqli_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="styleprofile.css">
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="">Green Star Auto Enterprise</a></div>
            <ul class="links">
                <li><a href="user_page.php">Home</a></li>
                <li><a href="aboutus.php">About</a></li>
                <li><a href="product.php">Product</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="my_booking.php">Order</a></li>
                <li><a href="login.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i> Log Out</a></li>
            </ul>
            <a href="userprofile.php" class="action_btn">User</a>
            <div class="toggle_btn">
                <i class="fa-solid fa-bars"></i>
            </div>

            <div class="dropdown_menu">
                <li><a href="">Home</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Product</a></li>
                <li><a href="">Gallery</a></li>
                <li><a href="">Login</a></li>
                <li><a href="" class="action_btn">User</a></li>
            </div>
        </nav>
    </header>

    <div class="form-container">
        <?php if (isset($user_data)): ?>
         

            <!-- Display current user information -->
            <form action="" method="post" enctype="multipart/form-data">
                <!-- <h2>Profile</h2> -->
                <!-- <hr> -->
                <div class="current-info">
                    <div class="profile-picture">
                        <img src="<?php echo $user_data['photo']; ?>" alt="Profile Picture" id="currentProfilePicture">
                    </div>
                    <p id="currentUsername"><?php echo $user_data['name']; ?></p>
                    <p id="currentPhone">+60 <?php echo $user_data['phone']; ?></p>
                </div>

                <!-- Form for updating information -->
                <div class="form-row">
                    <div class="left-column">
                        <h2>Basic information</h2>
                        <h3>Some details may be visible to other user</h3>
                        <label for="new_name">Username:</label>
                        <input type="text" name="new_name" placeholder="Enter new username" value="<?php echo $user_data['name']; ?>">

                        <label for="new_name">Email:</label>
                        <input type="text" name="new_email" placeholder="Email" value="<?php echo $user_data['email']; ?>" readonly>

                        <label for="new_phone">Phone:</label>
                        <input type="text" name="new_phone" placeholder="Enter new phone number" value="<?php echo $user_data['phone']; ?>">

                        <label for="profile_picture">Profile Picture:</label>
                        <input type="file" name="profile_picture" accept="image/*">
                    </div>
                    <div class="right-column">
                        <h2>Password</h2>
                        <h3>A secure password help you to protect your account.</h3>
                        <label for="new_password">Password:</label>
                        <input type="password" name="new_password" placeholder="Enter new password">
                        
                        <h4><i class="fa-solid fa-exclamation"></i> <i class="fa-solid fa-exclamation"></i> Ensure that your password is strong and follows the guidelines provided.</h4>
                        
                            <ul>
                                <li>At least one uppercase letter</li>
                                <li>At least one lowercase letter</li>
                                <li>At least one numeral</li>
                                <li>At least one special character</li>
                                <li>At least 8 characters long</li>
                            </ul>
                        
                    </div>
                </div>

                <input type="submit" name="update" value="Update Profile" class="form-btn">
               <!-- Display success or error message -->
               <?php if (!empty($success_message)): ?>
                    <div class="success-message">
                        <?php echo $success_message; ?>
                    </div>
                    <script>
                        updateDisplayedValues('<?php echo $user_data['name']; ?>', '<?php echo $user_data['phone']; ?>', '<?php echo $user_data['photo']; ?>');
                    </script>
                <?php endif; ?>
                <?php if (!empty($error_message)): ?>
                    <div class="error-message">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>
            </form>


        <?php endif; ?>
    </div>

    <!-- footer-->

    <script>
        // Function to update the displayed values
        function updateDisplayedValues(newName, newPhone, newPhoto) {
            document.getElementById('currentUsername').textContent = 'Username: ' + newName;
            document.getElementById('currentPhone').textContent = 'Phone: +60' + newPhone;
            document.getElementById('currentProfilePicture').src = newPhoto;
        }
    </script>
</body>

</html>
