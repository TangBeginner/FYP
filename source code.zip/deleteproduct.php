<?php
include 'config.php';

if (isset($_GET['model_id'])) {
    $model_id = $_GET['model_id'];
    $deletePaymentsQuery = "DELETE FROM payments WHERE car_id IN (SELECT car_id FROM car WHERE model_id = $model_id)";
    $deletePaymentsResult = $conn->query($deletePaymentsQuery);
    if (!$deletePaymentsResult) {
        echo "Error deleting associated payments: " . $conn->error;
        exit;
    }
    $deleteImagesQuery = "DELETE FROM car_image WHERE car_id IN (SELECT car_id FROM car WHERE model_id = $model_id)";
    $deleteImagesResult = $conn->query($deleteImagesQuery);
    if (!$deleteImagesResult) {
        echo "Error deleting associated images: " . $conn->error;
        exit; 
    }
    // Delete the product from the car table
    $deleteCarQuery = "DELETE FROM car WHERE model_id = $model_id";
    $deleteCarResult = $conn->query($deleteCarQuery);
    if (!$deleteCarResult) {
        echo "Error deleting product: " . $conn->error;
        exit; 
    }
    $deleteModelQuery = "DELETE FROM model WHERE model_id = $model_id AND NOT EXISTS (SELECT 1 FROM car WHERE model_id = $model_id)";
    $deleteModelResult = $conn->query($deleteModelQuery);
    if (!$deleteModelResult) {
        echo "Error deleting model: " . $conn->error;
        exit; 
    }
    $deleteBrandQuery = "DELETE FROM brand WHERE brand_id = (SELECT brand_id FROM model WHERE model_id = $model_id) AND NOT EXISTS 
    (SELECT 1 FROM model WHERE brand_id = (SELECT brand_id FROM model WHERE model_id = $model_id))";
    $deleteBrandResult = $conn->query($deleteBrandQuery);
    if (!$deleteBrandResult) {
        echo "Error deleting brand: " . $conn->error;
        exit; 
    }
    header('Location: productmanagement.php');
    exit; 
} else {
    echo "Invalid product ID";
}
?>