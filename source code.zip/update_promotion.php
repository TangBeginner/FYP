<?php
@include 'config.php';
session_start();

if (!isset($_SESSION['admin_name'])) {
    header('location:login_form.php');
    exit(); // Ensure script execution stops after redirection
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if promotions array is set and not empty
    if (isset($_POST['promotions']) && !empty($_POST['promotions'])) {
        // Ensure only a maximum of three promotions are selected
        $selectedPromotions = array_slice($_POST['promotions'], 0, 3);
        // Convert the array to a comma-separated string
        $promotionList = implode(',', $selectedPromotions);

        // Update the promotion list in the database
        $updateSql = "UPDATE promotions SET car_ids='$promotionList' WHERE id=1"; // Assuming promotions are stored in a table named 'promotions'
        if (mysqli_query($conn, $updateSql)) {
            echo "Promotion list updated successfully.";
        } else {
            echo "Error updating promotion list: " . mysqli_error($conn);
        }
    } else {
        echo "Please select at least one promotion.";
    }
} else {
    // Redirect if accessed directly
    header("location: admin_page.php");
    exit(); // Ensure script execution stops after redirection
}
?>
