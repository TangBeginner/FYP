<?php
@include 'config.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get feedback ID and new status from POST data
$feedbackId = $_POST['feedbackId'];
$newStatus = $_POST['newStatus'];

// Update the feedback status in the database
$updateQuery = "UPDATE feedback SET status = $newStatus WHERE id = $feedbackId";

if ($conn->query($updateQuery) === TRUE) {
    echo "Status updated successfully";
} else {
    echo "Error updating status: " . $conn->error;
}

$conn->close();
?>
