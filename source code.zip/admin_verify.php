<?php
include 'config.php';
session_start();

if (!isset($_SESSION['admin_name'])) {
    header('location:login_form.php');
    exit;
}

// Fetch all users (including verified and unverified)
$query = "SELECT * FROM user";
$result = mysqli_query($conn, $query);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['verify_user'])) {
        $user_id = $_POST['user_id'];
        $verify_query = "UPDATE user SET verify = 1 WHERE id = $user_id";
        mysqli_query($conn, $verify_query);
        header('Location: admin_verify.php');
        exit; 
    }

    if (isset($_POST['delete_user'])) {
        $user_id = $_POST['user_id'];
        $delete_query = "DELETE FROM user WHERE id = $user_id";
        if (mysqli_query($conn, $delete_query)) {
            header('Location: admin_verify.php');
            exit; 
        } else {
            echo "Error deleting record: " . mysqli_error($conn);
        }
    }
}
?>


<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>User Management</title>
   <link rel="stylesheet" href="styleAdmin.css">
   <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
   <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>
<body>
    
<div class="sidebar">
      <nav>
         <div class="logo">
            <a href="#"><span><img src="logo.jpg" alt="Logo"></span></a>
         </div>
         <ul>
            <li><a href="admin_page.php"><i class="fa-solid fa-house"></i> Home</a></li>
            <li class="active"><a href="admin_verify.php"><i class="fa-solid fa-user"></i> User Management</a></li>
            <li><a href="productmanagement.php"><i class="fa-solid fa-car"></i> Product</a></li>
            <li><a href="admin_order.php"><i class="fa-regular fa-file-lines"></i> Booking</a></li>
            <li><a href="notification.php"><i class="fa-solid fa-bell"></i> Notification</a></li>
            <li><a href="feedback.php"><i class="fa-regular fa-comment"></i> Feedback</a></li>
            <li><a href="login.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i> Log Out</a></li>
         </ul>
      </nav>
   </div>
    
   <div class="main-content">
      <h3>User Management</h3>
      
      <div class="search-bar">
         <input type="text" id="search-input" placeholder="Search by name, email, or user type...">
         <button onclick="applyFilters()">Search</button>
      </div>

      <table class="verify-table">
         <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>User Type</th>
            <th>Action</th>
         </tr>

         <?php while ($user = mysqli_fetch_assoc($result)): ?>
            <tr>
               <td><?php echo $user['id']; ?></td>
               <td><?php echo $user['name']; ?></td>
               <td><?php echo $user['email']; ?></td>
               <td><?php echo $user['user_type']; ?></td>
               <td>
               <div class="button-container">
                  <form method="post" class="user-verify-form">
                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                        <?php if ($user['verify'] == 1): ?>
                           <input type="submit" value="Verified" class="btn verify-btn verified" disabled>
                        <?php else: ?>
                           <input type="submit" name="verify_user" value="Verify" class="btn verify-btn">
                        <?php endif; ?>
                  </form>
                  <!-- <form method="post" class="user-verify-form" onsubmit="return confirm('Are you sure you want to delete this user?');">
                     <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                     <input type="submit" name="delete_user" value="Delete" class="btn delete-btn">
                  </form> -->
               </div>
               </td>
            </tr>
         <?php endwhile; ?>
      </table>
   </div>
   
   <script>
   function applyFilters() {
      var input, filter, table, tr, td, i;
      input = document.getElementById("search-input");
      filter = input.value.toUpperCase();
      table = document.getElementsByClassName("verify-table")[0];
      tr = table.getElementsByTagName("tr");

      for (i = 0; i < tr.length; i++) {
         if (tr[i].getElementsByTagName("th").length === 0) { // Check if it's not a header row
            td = tr[i].getElementsByTagName("td");
            var found = false;
            for (var j = 0; j < td.length; j++) {
               if (td[j]) {
                  if (td[j].innerHTML.toUpperCase().indexOf(filter) > -1) {
                     found = true;
                  }
               }
            }
            if (found) {
               tr[i].style.display = "";
            } else {
               tr[i].style.display = "none";
            }
         }
      }
   }
   </script>
</body>
</html>

