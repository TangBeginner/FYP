<?php
include 'config.php';
session_start();

// Check if the user is logged in as an admin (you may need to adjust this based on your authentication mechanism)
// if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
//     header("Location: login.php"); // Redirect to the login page if not logged in as admin
//     exit();
// }

// Initialize variables for search input
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Retrieve orders from the database with search filter
$ordersQuery = "SELECT payments.*, meet_times.meet_datetime, car.specification,
car.price, model.name AS model_name, model.year AS model_year,
brand.name AS brand_name, brand.country AS brand_country,
MAX(car_image.image_path) AS image_path
FROM payments
JOIN meet_times ON payments.payment_id = meet_times.payment_id
JOIN car ON payments.car_id = car.car_id
JOIN model ON car.model_id = model.model_id
JOIN brand ON model.brand_id = brand.brand_id
JOIN car_image ON car.car_id = car_image.car_id
WHERE
    car.specification LIKE '%$search%' OR
    payments.contact_name LIKE '%$search%' OR
    payments.contact_phone LIKE '%$search%' OR
    meet_times.meet_datetime LIKE '%$search%'
GROUP BY payments.payment_id
ORDER BY payments.payment_date DESC;";

$ordersResult = $conn->query($ordersQuery);
// Check for query execution errors
if (!$ordersResult) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styleAdminOrder.css"> <!-- Add your stylesheet link here -->
    <title>Admin - View Orders</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
</head>

<body>

    <div class="sidebar">
        <nav>
            <div class="logo">
                <a href="#"><span><img src="logo.jpg"></span></a>
            </div>
            <ul>
                <li><a href="admin_page.php"><i class="fa-solid fa-house"></i> Home</a></li>
                <li><a href="admin_verify.php"><i class="fa-solid fa-user"></i> User management</a></li>
                <li><a href="productmanagement.php"><i class="fa-solid fa-car"></i> Product</a></li>
                <li class="active"><a href="admin_order.php"><i class="fa-regular fa-file-lines"></i> Booking</a></li>
                <li><a href="notification.php"><i class="fa-solid fa-bell"></i> Notification</a></li>
                <li><a href="feedback.php"><i class="fa-regular fa-comment"></i> Feedback</a></li>
                <li><a href="login.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i>
                        Log Out</a></li>
            </ul>
        </nav>
    </div>

    <h3>Booking Details</h3>

    <div class="search-container">
    <form method="GET">
        <input type="text" name="search" placeholder="Search by contact name, contact number, date and time" value="<?php echo $search; ?>">
        <button type="submit">Search</button>
    </form>
    </div>


    <div class="order-list">
        <table>
            <thead>
                <tr>
                    <th>Car ID</th>
                    <th>Car</th>
                    <th>Car Price</th>
                    <th>Contact Name</th>
                    <th>Contact Phone</th>
                    <th>Date & Time</th>
                    <th>Booking Fee</th>
                    <th>Transaction Photo</th>
                    <th>Transaction Status</th>
                    <th>Confirmation Status</th>
                </tr>
            </thead>
            <tbody>
            <?php
            // Check if there are rows in the result set
            if ($ordersResult->num_rows > 0) {
                while ($order = $ordersResult->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $order['car_id'] . '</td>';
                    echo '<td>' . $order['brand_name'] . ' ' . $order['model_name'] . '</td>';
                    echo '<td>RM ' . $order['price'] . '</td>';
                    echo '<td>' . $order['contact_name'] . '</td>';
                    echo '<td>' . $order['contact_phone'] . '</td>';
                    echo '<td>' . $order['meet_datetime'] . '</td>';
                    echo '<td>RM ' . $order['payment_amount'] . '</td>';
                    echo '<td><img src="transaction_photos/' . $order['transaction_photo'] . '" alt="Transaction Photo" onclick="openModal(\'transaction_photos/' . $order['transaction_photo'] . '\')"></td>';
                    echo '<td>' . ucfirst($order['transaction_status']) . '</td>';
                    echo '<td>';
                    if ($order['transaction_status'] === 'pending') {
                        echo '<button class="confirm-toggle-btn" onclick="toggleTransaction(' . $order['payment_id'] . ', \'confirm\')">Confirm</button>';
                    } else {
                        echo '<button class="confirm-toggle-btn undo" onclick="toggleTransaction(' . $order['payment_id'] . ', \'undo\')">Cancel</button>';
                    }
                    echo '<button class="delete-btn" onclick="deleteTransaction(' . $order['payment_id'] . ')">Delete</button>';
                    echo '</td>';
                    echo '</tr>';
                } 
            } else {
                echo '<tr><td colspan="9">No orders found.</td></tr>';
            }
            ?>
        </tbody>
        </table>
    </div>

    <div id="imageModal" class="modal">
        <span class="close" onclick="closeModal()">&times;</span>
        <img id="modalImage" class="modal-content">
    </div>


    <script>
        function openModal(imagePath) {
            var modal = document.getElementById('imageModal');
            var modalImage = document.getElementById('modalImage');
            modalImage.src = imagePath;
            modal.style.display = 'block';
        }

        function closeModal() {
            var modal = document.getElementById('imageModal');
            modal.style.display = 'none';
        }

        function toggleTransaction(paymentId, action) {
            $.ajax({
                type: 'POST',
                url: 'toggle_transaction.php',
                data: { payment_id: paymentId, action: action },
                success: function (response) {
                    // Handle response, maybe update UI or show a message
                    location.reload(); // Refresh the page after successful confirmation
                }
            });
        }

        function deleteTransaction(paymentId) {
        if (confirm('Are you sure you want to delete this payment?')) {
            $.ajax({
                type: 'POST',
                url: 'delete_transaction.php',
                data: { payment_id: paymentId },
                success: function (response) {
                    // Handle response, maybe update UI or show a message
                    location.reload(); // Refresh the page after successful deletion
                }
            });
        }
    }
    </script>

</body>

</html>