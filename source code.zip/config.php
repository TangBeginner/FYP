<?php

$conn = mysqli_connect('localhost','root','','fyp_db');

?>