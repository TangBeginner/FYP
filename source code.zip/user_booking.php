<?php
// Include config file and start the session
include 'config.php';
session_start();

// Check if the car_id is provided in the URL
if (isset($_GET['car_id']) && !empty($_GET['car_id'])) {
    $carId = $conn->real_escape_string($_GET['car_id']);

    // Fetch details of the selected car
    $carDetailsQuery = "SELECT car.*, model.name as model_name, model.year as model_year, brand.name as brand_name, car_image.image_path, car.price as car_price, body_type.type as body_type
    FROM car
    JOIN model ON car.model_id = model.model_id
    JOIN brand ON model.brand_id = brand.brand_id
    JOIN car_image ON car.car_id = car_image.car_id
    JOIN body_type ON car.body_type_id = body_type.body_type_id
    WHERE car.car_id = '$carId'";

    $carDetailsResult = $conn->query($carDetailsQuery);

    if ($carDetailsResult->num_rows > 0) {
        $carDetails = $carDetailsResult->fetch_assoc();
    } else {
        die("Car details not found");
    }
} else {
    die("Car ID not provided");
}

// Check if the user clicked the "Book Now" button
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['book_now'])) {
    // Add the selected car to the cart (you can store this information in a session or database)
    $_SESSION['cart'][] = array(
        'car_id' => $carDetails['car_id'],
        'brand' => $carDetails['brand_name'],
        'model' => $carDetails['model_name'],
        'year' => $carDetails['model_year'],
        'car_price' => $carDetails['car_price'],
        'total_price' => 1000 // Booking fee is RM1000
    );

    // Redirect to the cart or payment page
    header("Location: product.php");
    exit();
}

$conn->close();

$previousPage = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'product.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Booking Details</title>
    <link rel="stylesheet" href="stylebooking.css"> 
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="">Green Star Auto Enterprise</a></div>
            <ul class="links">
            <li><a href="user_page.php">Home</a></li>
                <li><a href="aboutus.php">About</a></li>
                <li><a href="product.php">Product</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="my_booking.php">Order</a></li>
                <!-- <li><a href="user_booking.php"><i class="fa-solid fa-cart-shopping"></i> Order</a></li> -->
                <li><a href="login.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i>
                        Log Out</a></li>
            </ul>
            <a href="userprofile.php" class="action_btn">User</a>
            <div class="toggle_btn">
                <i class="fa-solid fa-bars"></i>
            </div>

            <div class="dropdown_menu">
                <li><a href="">Home</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Product</a></li>
                <li><a href="">Gallery</a></li>
                <li><a href="">Login</a></li>
                <li><a href="" class="action_btn">User</a></li>
            </div>
        </nav>
    </header>

    <div class="back">
        <a href="product.php" class="back-link">&lt; Back to Search Results</a>
    </div>

    <a href="#" id="share-link" class="share-icon" title="Share"><i class="fa-regular fa-share-from-square"></i></a>

    <div class="wrapper">
        <div class="outer">
            <div class="content animated fadeInLeft">
                <!-- <span class="bg animated fadeInDown">BOOKING DETAILS</span> -->
                <h1>
                    <?php echo $carDetails['brand_name'] . ' ' . $carDetails['model_name']; ?>
                </h1>
                <h3>
                    <span class="car-price"><?php echo 'RM '.$carDetails['car_price'] ?></span><br>
                    <?php echo 'Year Made&nbsp&nbsp&nbsp&nbsp ' . ': '. $carDetails['model_year'] ?><br>
                    <?php echo 'Body Type&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp' . ': '.$carDetails['body_type'] ?>
                </h3>
                <div class='details-specification'>
                    Detail of Specification
                </div>
                <p>
                    <?php echo $carDetails['specification']; ?>
                </p>

                <div class="button-group">
                    
                    <form method="post" action="payment.php?car_id=<?php echo $carDetails['car_id'];?>">
                        <button type="submit" name="book_now" class="cart-btn">
                            <i class="cart-icon ion-bag"></i>BOOK NOW
                        </button>
                    </form>
                </div>

            </div>
       

            <div class="slider">
                <?php foreach ($carDetailsResult as $image) { ?>
                    <div class="slide">
                        <img src="<?php echo $image['image_path']; ?>" alt="Car Image">
                    </div>
                <?php } ?>
                <!-- Navigation arrows -->
                <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                <a class="next" onclick="plusSlides(1)">&#10095;</a>
            </div>
        </div>
    </div>

    <div class="whatsapp">
    Need more help? Contact us via &nbsp<a href="whatsapp://send?phone=+6011-24157828&text=I'm interested in estimating my car's price"> <i class="fa-brands fa-whatsapp"></i> Whatsapp</a>
    </div>

    <!--footer-->
    <footer class="footer-section">
        <div class="footer-container">
            <div class="footer-cta pt-5 pb-5">
                <div class="row">
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta">
                            <i class="fas fa-map-marker-alt"></i>
                            <div class="cta-text">
                                <h4>Find us</h4>
                                <span> 80, Jalan Industri 2, Taman Seri Bayu, <br>14300 Nibong Tebal, Pulau Pinang</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta1">
                            <i class="fas fa-phone"></i>
                            <div class="cta-text">
                                <h4>Call us</h4>
                                <span>012-518 2468</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta2">
                            <i class="far fa-envelope-open"></i>
                            <div class="cta-text">
                                <h4>Mail us</h4>
                                <span>Khooi197671@gmail.com</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-content pt-5 pb-5">
                <div class="row2">
                    <div class="col-xl-4 col-lg-4 mb-50">
                        <div class="footer-widget">
                            <div class="footer-logo">
                                <a href="#">Green Star Auto Enterprise</a>
                            </div>
                            <hr>
                            <div class="footer-text">
                                <p>Our comprehensive used car booking website offers a seamless experience for users to browse a wide selection of reliable pre-owned vehicles,
                                compare features and prices, read customer reviews, and conveniently book test drives or purchases, all through an intuitive and secure online platform.</p>
                            </div>
                            <div class="footer-social-icon">
                                <span>Follow us</span>
                                <a href="#"><i class="fab fa-facebook-f facebook-bg"></i></a>
                                <a href="#"><i class="fab fa-twitter twitter-bg"></i></a>
                                <a href="#"><i class="fab fa-instagram instagram-bg"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-30">
                        <div class="footer-widget">
                            <div class="footer-widget-heading">
                                <h3>Useful Links</h3>
                            </div>
                            <ul>
                                <li><a href="user_page.php">Home</a></li>
                                <li><a href="aboutus.php">About us</a></li>
                                <li><a href="product.php">Product</a></li>
                                <li><a href="gallery.php">Gallery</a></li>                                         
                                <li><a href="whatsapp://send?phone=+6011-24157828&">Contact us</a></li>
               
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-50">
                        <div class="footer-widget">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-area">
            <div class="footer-container">
                <div class="row3">
                    <div class="col-xl-6 col-lg-6 text-center text-lg-left">
                        <div class="copyright-text">
                            <p>Copyright &copy; 2024, All Right Reserved </p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 d-none d-lg-block text-right">
                        <div class="footer-menu">
                            <ul>
                                <li><a href="user_page.php">Home</a></li>
                                <li><a href="#">Terms</a></li>
                                <li><a href="#">Privacy</a></li>
                                <li><a href="#">Policy</a></li>
                                <li><a href="#">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>

<script>
var slideIndex = 0;
showSlides(slideIndex);

function plusSlides(n) {
    showSlides(slideIndex += n);
}

function currentSlide(n) {
    showSlides(slideIndex = n);
}

function showSlides(n) {
    var i;
    var slides = document.getElementsByClassName("slide");
    if (n >= slides.length) {slideIndex = 0}    
    if (n < 0) {slideIndex = slides.length - 1}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }
    slides[slideIndex].style.display = "block";  
}

document.getElementById('share-link').addEventListener('click', function() {
            // Create an input element
            var input = document.createElement('input');
            input.setAttribute('value', window.location.href);
            document.body.appendChild(input);
            
            // Select the input
            input.select();
            
            // Copy the URL to the clipboard
            document.execCommand('copy');
            
            // Remove the input element
            document.body.removeChild(input);
            
            // Alert the user
            alert('Link copied to clipboard');
        });



</script>

</html>