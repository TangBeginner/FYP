<?php
include 'config.php';

$errors = []; // Initialize error array
$name = $email = $password = $cpassword = ""; // Initialize variables to store form values

if (isset($_POST['submit'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    $user_type = 'user'; // Set user type to 'user' automatically

    // Validate password
    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $password)) {
        $errors[] = "Password must include uppercase, lowercase, number, special character, and be at least 8 characters long.";
    }

    // Check if passwords match
    if ($password !== $cpassword) {
        $errors[] = 'Passwords do not match!';
    }

    // Proceed only if there are no validation errors
    if (empty($errors)) {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $select = "SELECT * FROM user WHERE email = '$email'";
        $result = mysqli_query($conn, $select);

        if (mysqli_num_rows($result) > 0) {
            $errors[] = 'User already exists!';
        } else {
            $insert = "INSERT INTO user (name, email, password, user_type, verify) VALUES ('$name', '$email', '$hashed_password', '$user_type', 0)";
            mysqli_query($conn, $insert);
            header('Location: login.php');
            exit(); // Ensure no further code is executed after redirection
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Form</title>

    <!-- custom css file link  -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="">Green Star Auto Enterprise</a></div>
        </nav>
    </header>
    <div class="form-container">
        <form action="" method="post">
            <h2>Green Star Auto Enterprise</h2>
            <h3>Register Now</h3>
            <?php
            if (!empty($errors)) {
                foreach ($errors as $error) {
                    echo '<span class="error-msg">' . $error . '</span>';
                }
            }
            ?>
            <input type="text" name="name" required placeholder="Enter your name" value="<?php echo htmlspecialchars($name); ?>">
            <input type="email" name="email" required placeholder="Enter your email" value="<?php echo htmlspecialchars($email); ?>">
            <input type="password" name="password" required placeholder="Enter your password" value="<?php echo htmlspecialchars($password); ?>">
            <input type="password" name="cpassword" required placeholder="Confirm your password" value="<?php echo htmlspecialchars($cpassword); ?>">
            <input type="submit" name="submit" value="Register Now" class="form-btn">
            <p>Already have an account? <a href="login.php">Login now</a></p>
        </form>
    </div>

</body>

</html>
