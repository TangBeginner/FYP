<?php

@include 'config.php';

session_start();


if (!isset($_SESSION['admin_name'])) {
   header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>admin page</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="styleAdmin.css">
   <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
   <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

</head>

<body>

   <div class="sidebar">
      <nav>
         <div class="logo">
            <a href="#"><span><img src="logo.jpg"></span></a>
         </div>
         <ul>
            <li class="active"><a href="admin_page.php"><i class="fa-solid fa-house"></i> Home</a></li>
            <li><a href="admin_verify.php"><i class="fa-solid fa-user"></i> User management</a></li>
            <li><a href="productmanagement.php"><i class="fa-solid fa-car"></i> Product</a></li>
            <li><a href="admin_order.php"><i class="fa-regular fa-file-lines"></i> Booking</a></li>
            <li><a href="notification.php"><i class="fa-solid fa-bell"></i> Notification</a></li>
            <li><a href="feedback.php"><i class="fa-regular fa-comment"></i> Feedback</a></li>
            <li><a href="login.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i> Log Out</a></li>
         </ul>
      </nav>
   </div>

   <div class="main-content">
      <!-- <h1>Welcome to the Admin Page!</h1> -->

      <div class="panel-wrapper">
         <div class="panel-head">Banner</div>
         <div class="panel-body">
            <?php
            // Fetch banners from the database
            $sql = "SELECT * FROM banners";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
               while ($row = mysqli_fetch_assoc($result)) {
                  echo "<div class='banner-item' id='banner-{$row['id']}'>";
                  echo "<div class='banner-image'><img src='{$row['image']}' alt='Banner Image'></div>";
                  echo "<div class='delete-form'>";
                  echo "<form class='delete-banner-form' data-banner-id='{$row['id']}'>";
                  echo "<input type='hidden' name='banner_id' value='{$row['id']}'>";
                  echo "<button type='submit'>Delete</button>";
                  echo "</form>";
                  echo "</div>";
                  echo "</div>";
               }
            } else {
               echo "No banners found.";
            }

            // Close database connection
            mysqli_close($conn);
            ?>

            <form action="upload_banner.php" method="post" enctype="multipart/form-data">
               <div class="upload-wrapper">
                  <input type="file" name="banner_image" required>
                  <button type="submit">Upload</button>
               </div>
            </form>
         </div>
      </div>
   </div>




<script>
      $(document).ready(function() {
         $('.delete-banner-form').on('submit', function(event) {
            event.preventDefault();

            var bannerId = $(this).data('banner-id');
            var formData = $(this).serialize();

            $.ajax({
               url: 'delete_banner.php',
               type: 'POST',
               data: formData,
               success: function(response) {
                  var data = JSON.parse(response);
                  alert(data.message);
                  if (data.status === 'success') {
                     $('#banner-' + bannerId).remove();
                  }
               },
               error: function(xhr, status, error) {
                  alert('An error occurred: ' + error);
               }
            });
         });

         // Logout confirmation
         window.logoutConfirmation = function() {
            var logoutConfirmed = confirm("Are you sure you want to log out?");
            if (logoutConfirmed) {
               $.ajax({
                  type: 'POST',
                  url: 'logout.php',
                  success: function(response) {
                     window.location.href = "login.php";
                  },
                  error: function(error) {
                     console.error("Logout error:", error);
                  }
               });
            }
         }
      });
   </script>

</body>

</html>