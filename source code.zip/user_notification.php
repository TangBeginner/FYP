<?php
// user_notification.php

@include 'config.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    // Redirect to the login page if the user is not logged in
    header('location:login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Function to fetch new notifications
function getNewNotifications($conn, $user_id) {
    $get_notifications_query = "SELECT * FROM notification WHERE uid = '$user_id' AND type = 'user_notification' ORDER BY created_at DESC";
    $result = mysqli_query($conn, $get_notifications_query);

    $notifications = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $notifications[] = $row;
    }

    return $notifications;
}

// Fetch new notifications
$notifications = getNewNotifications($conn, $user_id);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Notification</title>
    <link rel="stylesheet" href="styleNotification.css"> <!-- Add your custom CSS file link -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>

<body>
    <div class="notification-container">
        <h1>User Notifications</h1>

        <div id="notifications">
            <?php
            foreach ($notifications as $notification) {
                echo '<div class="notification">' . $notification['message'] . '</div>';
            }
            ?>
        </div>
    </div>

    <script>
        // Function to periodically check for new notifications
        function checkForNewNotifications() {
            $.ajax({
                type: 'GET',
                url: 'check_notifications.php', // Create a separate PHP file for checking notifications
                dataType: 'json',
                success: function (data) {
                    // Update the notifications container with new notifications
                    $('#notifications').html(data.notifications);
                },
                complete: function () {
                    // Schedule the next check after a certain time interval (e.g., 5 seconds)
                    setTimeout(checkForNewNotifications, 5000);
                }
            });
        }

        // Initial check for notifications when the page loads
        $(document).ready(function () {
            checkForNewNotifications();
        });
    </script>
</body>

</html>
