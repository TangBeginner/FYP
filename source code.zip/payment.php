<?php
include 'config.php';
session_start();

// Check if the car_id is provided in the URL
if (isset($_GET['car_id']) && !empty($_GET['car_id'])) {
    $carId = $conn->real_escape_string($_GET['car_id']);

    // Fetch details of the selected car
    $carDetailsQuery = "SELECT car.*, model.name as model_name, model.year as model_year, brand.name as brand_name
                        FROM car
                        JOIN model ON car.model_id = model.model_id
                        JOIN brand ON model.brand_id = brand.brand_id
                        WHERE car.car_id = '$carId'";

    $carDetailsResult = $conn->query($carDetailsQuery);

    if ($carDetailsResult->num_rows > 0) {
        $carDetails = $carDetailsResult->fetch_assoc();
    } else {
        die("Car details not found");
    }
} else {
    die("Car ID not provided");
}

// Check if the user submitted the payment form
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_payment'])) {
    $paymentAmount = $conn->real_escape_string($_POST['payment_amount']);
    $transactionPhoto = $_FILES['transaction_photo']['name'];
    $contactName = $conn->real_escape_string($_POST['contact_name']);
    $contactPhone = $conn->real_escape_string($_POST['contact_phone']);
    $meetDate = $conn->real_escape_string($_POST['meet_date']);
    $meetTime = $conn->real_escape_string($_POST['meet_time']);
    $uploadPath = "transaction_photos/";

    move_uploaded_file($_FILES['transaction_photo']['tmp_name'], $uploadPath . $transactionPhoto);

    // Get the user_id from the session
    $userId = $_SESSION['user_id'];

    // Start a transaction
    $conn->begin_transaction();

    try {
        // Check if the car is still available
        $checkQuery = "SELECT status FROM car WHERE car_id = ? FOR UPDATE";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bind_param("i", $carId);
        $stmt->execute();
        $stmt->bind_result($status);
        $stmt->fetch();
        $stmt->close();

        if ($status === 'available') {
            // Update the car status to booked
            $updateQuery = "UPDATE car SET status = 'booked' WHERE car_id = ?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("i", $carId);
            $stmt->execute();
            $stmt->close();

            // Insert payment record
            $insertPaymentQuery = "INSERT INTO payments (car_id, user_id, payment_amount, transaction_photo, contact_name, contact_phone) 
                                   VALUES ('$carId', '$userId', '$paymentAmount', '$transactionPhoto', '$contactName', '$contactPhone')";

            if ($conn->query($insertPaymentQuery) === TRUE) {
                // Get the payment ID
                $paymentId = $conn->insert_id;
                $insertMeetTimeQuery = "INSERT INTO meet_times (payment_id, meet_datetime) VALUES ('$paymentId', '$meetDate $meetTime')";
                $conn->query($insertMeetTimeQuery);

                // Commit the transaction
                $conn->commit();

                // Display success message
                echo '<script>alert("Payment successful! Thank you."); window.location.href = "my_booking.php";</script>';
                exit();
            } else {
                throw new Exception("Error inserting payment details: " . $conn->error);
            }
        } else {
            throw new Exception("Sorry, this car has already been booked.");
        }
    } catch (Exception $e) {
        // Rollback the transaction in case of an error
        $conn->rollback();
        die("An error occurred: " . $e->getMessage());
    }
}

$conn->close();

$previousPage = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'product.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Booking Details</title>
    <link rel="stylesheet" href="stylebooking1.css">
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="">Green Star Auto Enterprise</a></div>
            <ul class="links">
            <li><a href="user_page.php">Home</a></li>
                <li><a href="aboutus.php">About</a></li>
                <li><a href="product.php">Product</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="my_booking.php">Order</a></li>
                <!-- <li><a href="user_booking.php"><i class="fa-solid fa-cart-shopping"></i> Order</a></li> -->
                <li><a href="logout.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i>
                        Log Out</a></li>
            </ul>
            <a href="userprofile.php" class="action_btn">User</a>
            <div class="toggle_btn">
                <i class="fa-solid fa-bars"></i>
            </div>

            <div class="dropdown_menu">
                <li><a href="">Home</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Product</a></li>
                <li><a href="">Gallery</a></li>
                <li><a href="">Login</a></li>
                <li><a href="" class="action_btn">User</a></li>
            </div>
        </nav>
    </header>

    <nav aria-label="breadcrumb">
        <ul class="breadcrumb">
            < &nbsp
            <li><a href="<?php echo $previousPage; ?>">Car list</a></li>
            <li>Booking Details</li>
        </ul>
    </nav>
    
    <!-- Add the payment form in payment.php -->
    <form action="" method="post" enctype="multipart/form-data">
        <h2>Payment</h2>
            <hr><br>
            <p class="payment-details">Booking car&nbsp&nbsp&nbsp&nbsp: <span><?php echo $carDetails['brand_name'] . ' ' . $carDetails['model_name']; ?></span></p>
            <p class="payment-details">Booking Fee&nbsp&nbsp&nbsp&nbsp: <span>RM 1000</span></p>
        <br>
        <div class="line">
            <hr>
        </div>
      
        <div class="bank-details">
        <p> <i class="fa-solid fa-circle-exclamation"></i>    Please pay the booking fee by online banking.</p>
            <div class="bank-image">
                <img src="img/publicbank.png" alt="public bank">
            </div>    
            <h1>public islamic bank</h1>
            <h2>Name: Green Star Auto Enterprise<br>Bank account: 32012xxxxxxxx</h2>
        <br>
        <p> <i class="fa-solid fa-circle-exclamation"></i>    Please fill in your information.</p>
            <label for="contact_name">Contact Name:</label>
            <input type="text" name="contact_name" placeholder="Enter your legal name" required>

            <label for="contact_phone">Contact Phone:</label>
            <input type="tel" name="contact_phone" placeholder="Enter your correct phone number" required>
            
            <p> <i class="fa-solid fa-circle-exclamation"></i>    Please select your time for meeting.(9am-6pm everyday except Sunday)</p>
            <label for="meet_date">Date:</label>
            <input type="date" name="meet_date" min="<?php echo date('Y-m-d'); ?>" required>

            <label for="meet_time">Time:</label>
            <input type="time" name="meet_time" required>

            <label for="payment_amount">Payment Amount:</label>
            <input type="text" name="payment_amount" placeholder="" required>

            <p> <i class="fa-solid fa-circle-exclamation"></i>    Please upload your transaction photo.</p>
            <label for="transaction_photo">Transaction Photo:</label>
            <input type="file" name="transaction_photo" accept="image/*" required>

            <input type="submit" name="submit_payment" value="Submit Payment">
        </div>
    </form>

     <!--footer-->
     <footer class="footer-section">
        <div class="footer-container">
            <div class="footer-cta pt-5 pb-5">
                <div class="row">
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta">
                            <i class="fas fa-map-marker-alt"></i>
                            <div class="cta-text">
                                <h4>Find us</h4>
                                <span> 80, Jalan Industri 2, Taman Seri Bayu, <br>14300 Nibong Tebal, Pulau Pinang</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta1">
                            <i class="fas fa-phone"></i>
                            <div class="cta-text">
                                <h4>Call us</h4>
                                <span>012-518 2468</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta2">
                            <i class="far fa-envelope-open"></i>
                            <div class="cta-text">
                                <h4>Mail us</h4>
                                <span>Khooi197671@gmail.com</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-content pt-5 pb-5">
                <div class="row2">
                    <div class="col-xl-4 col-lg-4 mb-50">
                        <div class="footer-widget">
                            <div class="footer-logo">
                                <a href="#">Green Star Auto Enterprise</a>
                            </div>
                            <hr>
                            <div class="footer-text">
                                <p>Our comprehensive used car booking website offers a seamless experience for users to browse a wide selection of reliable pre-owned vehicles,
                                compare features and prices, read customer reviews, and conveniently book test drives or purchases, all through an intuitive and secure online platform.</p>
                            </div>
                            <div class="footer-social-icon">
                                <span>Follow us</span>
                                <a href="#"><i class="fab fa-facebook-f facebook-bg"></i></a>
                                <a href="#"><i class="fab fa-twitter twitter-bg"></i></a>
                                <a href="#"><i class="fab fa-instagram instagram-bg"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-30">
                        <div class="footer-widget">
                            <div class="footer-widget-heading">
                                <h3>Useful Links</h3>
                            </div>
                            <ul>
                                <li><a href="user_page.php">Home</a></li>
                                <li><a href="aboutus.php">About us</a></li>
                                <li><a href="product.php">Product</a></li>
                                <li><a href="gallery.php">Gallery</a></li>                                         
                                <li><a href="whatsapp://send?phone=+6011-24157828&text=I'm interested in estimating my car's price">Contact us</a></li>
               
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-50">
                        <div class="footer-widget">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-area">
            <div class="footer-container">
                <div class="row3">
                    <div class="col-xl-6 col-lg-6 text-center text-lg-left">
                        <div class="copyright-text">
                            <p>Copyright &copy; 2024, All Right Reserved </p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 d-none d-lg-block text-right">
                        <div class="footer-menu">
                            <ul>
                                <li><a href="#">Home</a></li>
                                <li><a href="#">Terms</a></li>
                                <li><a href="#">Privacy</a></li>
                                <li><a href="#">Policy</a></li>
                                <li><a href="#">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>
