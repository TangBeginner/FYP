<?php
@include 'config.php';
session_start();

if (!isset($_SESSION['admin_name'])) {
    header('location:login_form.php');
    exit; // Added exit after header redirect
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the message variable
$message = '';

// Retrieve body types from the database
$bodyTypesQuery = "SELECT * FROM body_type";
$result = $conn->query($bodyTypesQuery);
$bodyTypes = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $bodyTypes[] = $row;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $brand = $_POST["brand"];
    $model = $_POST["model"];
    $year = $_POST["year"];
    $price = $_POST["price"];
    $specification = nl2br($_POST["specification"]);
    $bodyType = $_POST["body_type"];

    // Insert data into the brand table
    $insertBrandQuery = "INSERT INTO brand (name, country) VALUES ('$brand', 'Unknown')";
    $conn->query($insertBrandQuery);

    // Get the brand_id of the inserted brand
    $brandId = $conn->insert_id;

    // Insert data into the model table
    $insertModelQuery = "INSERT INTO model (brand_id, name, year) VALUES ('$brandId', '$model', '$year')";
    $conn->query($insertModelQuery);

    // Get the model_id of the inserted model
    $modelId = $conn->insert_id;

    // Insert data into the car table
    $insertCarQuery = "INSERT INTO car (model_id, specification, price, body_type_id, image_paths) 
                        VALUES ('$modelId', '$specification', '$price', '$bodyType', '')";
    $conn->query($insertCarQuery);

    // Get the car_id of the inserted car
    $carId = $conn->insert_id;

    // Handle multiple image uploads
    $images = $_FILES["image"];
    $imagePaths = [];

    // Loop through each uploaded file
    foreach ($images["tmp_name"] as $key => $tmp_name) {
        $image = $images["name"][$key];
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($image);

        // Move uploaded image to the 'uploads' folder
        if (move_uploaded_file($tmp_name, $target_file)) {
            $imagePaths[] = $target_file;
            // Insert image path into car_image table
            $insertImageQuery = "INSERT INTO car_image (car_id, image_path) VALUES ('$carId', '$target_file')";
            $conn->query($insertImageQuery);
        } else {
            $message = "Sorry, there was an error uploading your files.";
        }
    }

    // Update the image_paths field in the car table
    if (!empty($imagePaths)) {
        $imagePathsString = implode(',', $imagePaths);
        $updateCarQuery = "UPDATE car SET image_paths = '$imagePathsString' WHERE car_id = $carId";
        $conn->query($updateCarQuery);
    }

    $message = "Product(s) added successfully!";
}

$conn->close();
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link rel="stylesheet" href="styleAddProduct.css">
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

</head>

<body>

    <div class="sidebar">
        <nav>
            <div class="logo">
                <a href="#"><span><img src="logo.jpg"></span></a>
            </div>
            <ul>
                <li><a href="admin_page.php"><i class="fa-solid fa-house"></i> Home</a></li>
                <li><a href="admin_verify.php"><i class="fa-solid fa-user"></i> User management</a></li>
                <li class="active"><a href="productmanagement.php"><i class="fa-solid fa-car"></i> Product</a></li>
                <li><a href="admin_order.php"><i class="fa-regular fa-file-lines"></i> Booking</a></li>
                <li><a href="notification.php"><i class="fa-solid fa-bell"></i> Notification</a></li>
                <li><a href="feedback.php"><i class="fa-regular fa-comment"></i> Feedback</a></li>
                <li><a href="login.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i>
                        Log Out</a></li>
            </ul>
        </nav>
    </div>

    <div class="back-btn">
        <button class="back-button" onclick="goBack()">Back</button>
    </div>
    
    <main class="add">

        <!-- Echo section -->
        <div class="echo-section">
            <?php
            // Display the message based on success or failure
            if (!empty($message)) {
                $class = (strpos($message, 'successfully') !== false) ? 'success' : 'error';
                echo '<div class="message ' . $class . '">' . $message . '</div>';
            }
            ?>
        </div>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST"
            enctype="multipart/form-data">
            <div>
                <label for="brand">Brand</label>
                <input type="text" id="brand" name="brand" class="add" required />
            </div>
            <div>
                <label for="model">Model</label>
                <input type="text" id="model" name="model" class="add" required />
            </div>
            <div>
                <label for="body_type">Body Type</label>
                <select id="body_type" name="body_type" class="add" required>
                    <?php foreach ($bodyTypes as $type) : ?>
                        <option value="<?php echo $type['body_type_id']; ?>"><?php echo $type['type']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="year">Year</label>
                <input type="number" id="year" name="year" min="1900" class="add" required />
            </div>
            <div>
                <label for="price">Price</label>
                <input type="number" id="price" name="price" min="0" class="add" required />
            </div>
            <div>
                <label for="specification">Specification</label>
                <textarea id="specification" name="specification" class="add" rows="4" required></textarea>
            </div>
            <div>
                <label for="image">Images</label>
                <input type="file" id="image" name="image[]" class="add" accept="image/*" multiple required />
            </div>
            <div>
                <button type="submit">Add</button>
            </div>
        </form>
    </main>

    <script>
        function goBack() {
            window.history.back();
        }
    </script>
</body>

</html>