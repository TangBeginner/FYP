<?php
@include 'config.php';

session_start();

// Initialize variables
$success_message = '';
$error_message = '';

// Check if the user is logged in
if (!isset($_SESSION['user_name'])) {
    header('location: login.php');
    exit();
}

$user_name = $_SESSION['user_name'];

// Fetch user details from the database
$select_user = "SELECT * FROM user WHERE name = '$user_name'";
$result_user = mysqli_query($conn, $select_user);

if ($result_user && mysqli_num_rows($result_user) > 0) {
    $user_data = mysqli_fetch_assoc($result_user);

    // Handle form submission for updating user information
    if (isset($_POST['update'])) {
        $new_name = mysqli_real_escape_string($conn, $_POST['new_name']);
        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        $new_phone = mysqli_real_escape_string($conn, $_POST['new_phone']);

        // Update user information in the database
        $update_query = "UPDATE user SET name = '$new_name', password = '$new_password', phone = '$new_phone' WHERE name = '$user_name'";
        if (mysqli_query($conn, $update_query)) {
            // Update successful, set success message
            $success_message = 'Profile updated successfully!';

            // Fetch updated user details from the database
            $select_updated_user = "SELECT * FROM user WHERE name = '$new_name'";
            $result_updated_user = mysqli_query($conn, $select_updated_user);

            if ($result_updated_user && mysqli_num_rows($result_updated_user) > 0) {
                $user_data = mysqli_fetch_assoc($result_updated_user);
            }
        } else {
            // Update failed, handle the error if needed
            $error_message = 'Error updating profile: ' . mysqli_error($conn);
        }

        // Handle photo upload
        if (!empty($_FILES['new_photo']['name'])) {
            // Validate file type
            $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');
            $file_extension = strtolower(pathinfo($_FILES['new_photo']['name'], PATHINFO_EXTENSION));

            if (!in_array($file_extension, $allowed_extensions)) {
                $error_message .= 'Invalid file type. Only JPG, JPEG, PNG, and GIF files are allowed.';
                // Handle the error accordingly
            }

            // Validate file size (adjust the size limit as needed)
            $max_file_size = 5 * 1024 * 1024; // 5 MB
            if ($_FILES['new_photo']['size'] > $max_file_size) {
                $error_message .= 'File size exceeds the limit (5 MB).';
                // Handle the error accordingly
            }

            // Move the uploaded file to the desired folder
            $photo_name = $_FILES['new_photo']['name'];
            $photo_tmp = $_FILES['new_photo']['tmp_name'];
            $photo_path = 'uploads/' . $photo_name; // Adjust the folder path as needed

            if (move_uploaded_file($photo_tmp, $photo_path)) {
                // Update the photo column in the database
                $update_photo_query = "UPDATE user SET photo = '$photo_name' WHERE name = '$user_name'";
                if (mysqli_query($conn, $update_photo_query)) {
                    // Photo update successful
                } else {
                    // Handle the error if photo update fails
                    $error_message .= 'Error updating photo: ' . mysqli_error($conn);
                }
            } else {
                // Handle the error if photo upload fails
                $error_message .= 'Error uploading photo.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="styleprofile.css">
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <!-- navigation---------------------------------------->
        <nav class="navbar">
            <div class="logo"><a href="">Green Star Auto Enterprise</a></div>
            <ul class="links">
                <li><a href="user_page.php">Home</a></li>
                <li><a href="aboutus.php">About</a></li>
                <li><a href="">Product</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="user_notification.php"></i> Notification</a></li>
                <li><a href="login.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i>
                        Log Out</a></li>
            </ul>
            <a href="userprofile.php" class="action_btn">User</a>
            <div class="toggle_btn">
                <i class="fa-solid fa-bars"></i>
            </div>

            <div class="dropdown_menu">
                <li><a href="">Home</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Product</a></li>
                <li><a href="">Gallery</a></li>
                <li><a href="">Login</a></li>
                <li><a href="" class="action_btn">User</a></li>
            </div>
        </nav>
    </header>

    <div class="form-container">
        <?php if (isset($user_data)): ?>
            <!-- Display success or error message -->
            <?php if (!empty($success_message)): ?>
                <div class="success-message">
                    <?php echo $success_message; ?>
                </div>
                <script>
                    // Call the JavaScript function to update displayed values
                    updateDisplayedValues('<?php echo $user_data['name']; ?>', '<?php echo $user_data['phone']; ?>');
                </script>
            <?php endif; ?>

            <!-- Display current user information -->
            <form action="" method="post" enctype="multipart/form-data">
                <h2>Edit Profile</h2>

                <!-- Display current user information -->
                <div class="current-info">
                    <div class="photo-container">
                        <p id="currentPhoto">
                            <img src="uploads/<?php echo !empty($user_data['photo']) ? $user_data['photo'] . '?' . time() : 'default.jpg'; ?>"
                                alt="User Photo" width="100px">
                        </p>
                    </div>
                    <div class="user-info">
                        <p id="currentUsername">Username:
                            <?php echo $user_data['name']; ?>
                        </p>
                        <p id="currentPhone">Phone:
                            <?php echo $user_data['phone']; ?>
                        </p>
                    </div>
                </div>


                <!-- Form for updating information -->
                <label for="new_name">New Username:</label>
                <input type="text" name="new_name" required placeholder="Enter new username">

                <label for="new_password">New Password:</label>
                <input type="password" name="new_password" required placeholder="Enter new password">

                <label for="new_phone">New Phone:</label>
                <input type="text" name="new_phone" placeholder="Enter new phone number">

                <label for="new_photo">New Photo:</label>
                <input type="file" name="new_photo" accept="image/*">

                <input type="submit" name="update" value="Update Profile" class="form-btn">
            </form>
        <?php endif; ?>
    </div>

    <!-- footer-->

    <script>
        // Function to update the displayed values
        function updateDisplayedValues(newName, newPhone) {
            document.getElementById('currentUsername').textContent = 'Current Username: ' + newName;
            document.getElementById('currentPhone').textContent = 'Current Phone: ' + newPhone;
            document.getElementById('currentPhoto').innerHTML = '<img src="uploads/<?php echo !empty($user_data['photo']) ? $user_data['photo'] . '?' : 'default.jpg'; ?>' + timestamp + '" alt="User Photo" width="100px">';
        }
    </script>
</body>

</html>