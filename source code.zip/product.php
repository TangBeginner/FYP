<?php
@include 'config.php';

// Start with a base query to fetch cars
$carsQuery = "SELECT car.*, model.name as model_name, model.year as model_year, brand.name as brand_name, body_type.type as body_type_name, GROUP_CONCAT(car_image.image_path) as image_paths
              FROM car
              JOIN model ON car.model_id = model.model_id
              JOIN brand ON model.brand_id = brand.brand_id
              JOIN car_image ON car.car_id = car_image.car_id
              JOIN body_type ON car.body_type_id = body_type.body_type_id
              WHERE car.status = 'available'"; // Add this line to filter only available cars

// Start with an empty array to store filter conditions
$whereConditions = [];

// Check if search query is provided
if (isset($_GET['search']) && is_array($_GET['search']) && !empty($_GET['search'])) {
    $searchTerms = $_GET['search'];
    $searchConditions = [];
    foreach ($searchTerms as $term) {
        $term = $conn->real_escape_string($term);
        $searchConditions[] = "(brand.name LIKE '%$term%' OR model.name LIKE '%$term%' OR model.year = '$term' OR body_type.type LIKE '%$term%')";
    }
    // Combine search conditions with OR operator
    $whereConditions[] = "(" . implode(" OR ", $searchConditions) . ")";
} elseif (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchQuery = $conn->real_escape_string($_GET['search']);
    // Check if the search query is a numeric value (year or body type)
    if (is_numeric($searchQuery)) {
        $whereConditions[] = "(model.year = '$searchQuery' OR body_type.body_type_id = '$searchQuery')";
    } else {
        // If not numeric, assume it's a brand name or model name
        $whereConditions[] = "(brand.name LIKE '%$searchQuery%' OR model.name LIKE '%$searchQuery%')";
    }
}


// Check if filter options are provided
if (isset($_GET['brand']) && !empty($_GET['brand'])) {
    $brandFilter = $conn->real_escape_string($_GET['brand']);
    $whereConditions[] = "brand.name = '$brandFilter'";
}

if (isset($_GET['body_type']) && !empty($_GET['body_type'])) {
    $bodyTypeFilter = $conn->real_escape_string($_GET['body_type']);
    $whereConditions[] = "body_type.body_type_id = '$bodyTypeFilter'";
}

if (isset($_GET['year']) && !empty($_GET['year'])) {
    $yearFilter = $conn->real_escape_string($_GET['year']);
    $whereConditions[] = "model.year = '$yearFilter'";
}

if (isset($_GET['price']) && !empty($_GET['price'])) {
    $priceRange = explode('-', $_GET['price']);
    $minPrice = $conn->real_escape_string($priceRange[0]);
    $maxPrice = $conn->real_escape_string($priceRange[1]);
    $whereConditions[] = "car.price BETWEEN '$minPrice' AND '$maxPrice'";
}

// Combine all conditions into a single WHERE clause
if (!empty($whereConditions)) {
    $carsQuery .= " AND " . implode(" AND ", $whereConditions); // Note the change here to use AND instead of WHERE
}

// Group by car ID to avoid duplicate rows
$carsQuery .= " GROUP BY car.car_id";

// Execute the query
$result = $conn->query($carsQuery);

if (!$result) {
    die("Query failed: " . $conn->error);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Product Page</title>
    <link rel="stylesheet" href="styleproduct.css">
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>

</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="">Green Star Auto Enterprise</a></div>
            <ul class="links">
            <li><a href="user_page.php">Home</a></li>
                <li><a href="aboutus.php">About</a></li>
                <li><a href="product.php">Product</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="my_booking.php">Order</a></li>
                <!-- <li><a href="user_booking.php"><i class="fa-solid fa-cart-shopping"></i> Order</a></li> -->
                <li><a href="logout.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i>
                        Log Out</a></li>
            </ul>
            <a href="userprofile.php" class="action_btn">User</a>
            <div class="toggle_btn">
                <i class="fa-solid fa-bars"></i>
            </div>

            <div class="dropdown_menu">
                <li><a href="">Home</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Product</a></li>
                <li><a href="">Gallery</a></li>
                <li><a href="">Login</a></li>
                <li><a href="" class="action_btn">User</a></li>
            </div>
        </nav>
    </header>

    <!-- searching bar -->
    <div class="search-filter-container">
        <form method="GET" action="product.php">
        <div class="search-bar">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" name="search" placeholder="What car are you looking for?">
            <button type="submit">Apply</button>
        </div>
        <div class="filter-options">
        <select name="brand">
                <option value="">Select Brand</option>
                <option value="honda" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'honda') ? 'selected' : ''; ?>>honda</option>
                <option value="toyota" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'toyota') ? 'selected' : ''; ?>>toyota</option>
                <option value="lexus" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'lexus') ? 'selected' : ''; ?>>lexus</option>
                <option value="nissan" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'nissan') ? 'selected' : ''; ?>>nissan</option>
                <option value="kia" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'kia') ? 'selected' : ''; ?>>kia</option>
                <option value="proton" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'proton') ? 'selected' : ''; ?>>proton</option>
                <option value="peroduo" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'peroduo') ? 'selected' : ''; ?>>peroduo</option>
                <option value="mazda" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'mazda') ? 'selected' : ''; ?>>mazda</option>
                <option value="volkswagen" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'volkswagen') ? 'selected' : ''; ?>>volkswagen</option>
                <option value="subaru" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'subaru') ? 'selected' : ''; ?>>subaru</option>
                <option value="mercedes" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'mercedes') ? 'selected' : ''; ?>>mercedes</option>
                <option value="bmw" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'bmw') ? 'selected' : ''; ?>>bmw</option>
                <option value="audi" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'audi') ? 'selected' : ''; ?>>audi</option>
                <option value="citroen" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'citroen') ? 'selected' : ''; ?>>citroen</option>
                <option value="peugeot" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'peugeot') ? 'selected' : ''; ?>>peugeot</option>
                <option value="hyundai" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'hyundai') ? 'selected' : ''; ?>>hyundai</option>
                <option value="volvo" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'volvo') ? 'selected' : ''; ?>>volvo</option>
                <option value="jeep" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'jeep') ? 'selected' : ''; ?>>jeep</option>
                <option value="cherry" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'cherry') ? 'selected' : ''; ?>>cherry</option>
                <option value="landrover" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'landrover') ? 'selected' : ''; ?>>landrover</option>
                <option value="renault" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'renault') ? 'selected' : ''; ?>>renault</option>
                <option value="mitsubishi" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'mitsubishi') ? 'selected' : ''; ?>>mitsubishi</option>
                <option value="isuzu" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'isuzu') ? 'selected' : ''; ?>>isuzu</option>
                <option value="suzuki" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'suzuki') ? 'selected' : ''; ?>>suzuki</option>
                <option value="ford" <?php echo (isset($_GET['brand']) && $_GET['brand'] == 'ford') ? 'selected' : ''; ?>>ford</option>
            </select>

            <select name="body_type">
                <option value="">Select Body Type</option>
                <option value="1" <?php echo (isset($_GET['body_type']) && $_GET['body_type'] == '1') ? 'selected' : ''; ?>>Sedan</option>
                <option value="2" <?php echo (isset($_GET['body_type']) && $_GET['body_type'] == '2') ? 'selected' : ''; ?>>SUV</option>
                <option value="3" <?php echo (isset($_GET['body_type']) && $_GET['body_type'] == '3') ? 'selected' : ''; ?>>Hatchback</option>
                <option value="4" <?php echo (isset($_GET['body_type']) && $_GET['body_type'] == '4') ? 'selected' : ''; ?>>MPV</option>
                <option value="5" <?php echo (isset($_GET['body_type']) && $_GET['body_type'] == '5') ? 'selected' : ''; ?>>Truck</option>
                <option value="6" <?php echo (isset($_GET['body_type']) && $_GET['body_type'] == '6') ? 'selected' : ''; ?>>Coupe</option>
                <option value="7" <?php echo (isset($_GET['body_type']) && $_GET['body_type'] == '7') ? 'selected' : ''; ?>>Van</option>
                <option value="8" <?php echo (isset($_GET['body_type']) && $_GET['body_type'] == '8') ? 'selected' : ''; ?>>Wagon</option>
                <option value="9" <?php echo (isset($_GET['body_type']) && $_GET['body_type'] == '9') ? 'selected' : ''; ?>>Convertible</option>
                <option value="10" <?php echo (isset($_GET['body_type']) && $_GET['body_type'] == '10') ? 'selected' : ''; ?>>Electric Vehicle(EV)</option>
            </select>

            <select name="year">
                <option value="">Select Year</option>
                <option value="2024" <?php echo (isset($_GET['year']) && $_GET['year'] == '2024') ? 'selected' : ''; ?>>2024</option>
                <option value="2023" <?php echo (isset($_GET['year']) && $_GET['year'] == '2023') ? 'selected' : ''; ?>>2023</option>
                <option value="2022" <?php echo (isset($_GET['year']) && $_GET['year'] == '2022') ? 'selected' : ''; ?>>2022</option>
                <option value="2021" <?php echo (isset($_GET['year']) && $_GET['year'] == '2021') ? 'selected' : ''; ?>>2021</option>
                <option value="2020" <?php echo (isset($_GET['year']) && $_GET['year'] == '2020') ? 'selected' : ''; ?>>2020</option>
                <option value="2019" <?php echo (isset($_GET['year']) && $_GET['year'] == '2019') ? 'selected' : ''; ?>>2019</option>
                <option value="2018" <?php echo (isset($_GET['year']) && $_GET['year'] == '2018') ? 'selected' : ''; ?>>2018</option>
                <option value="2017" <?php echo (isset($_GET['year']) && $_GET['year'] == '2017') ? 'selected' : ''; ?>>2017</option>
                <option value="2016" <?php echo (isset($_GET['year']) && $_GET['year'] == '2016') ? 'selected' : ''; ?>>2016</option>
                <option value="2015" <?php echo (isset($_GET['year']) && $_GET['year'] == '2015') ? 'selected' : ''; ?>>2015</option>
                <option value="2014" <?php echo (isset($_GET['year']) && $_GET['year'] == '2014') ? 'selected' : ''; ?>>2014</option>
                <option value="2013" <?php echo (isset($_GET['year']) && $_GET['year'] == '2013') ? 'selected' : ''; ?>>2013</option>
                <option value="2012" <?php echo (isset($_GET['year']) && $_GET['year'] == '2012') ? 'selected' : ''; ?>>2012</option>
                <option value="2011" <?php echo (isset($_GET['year']) && $_GET['year'] == '2011') ? 'selected' : ''; ?>>2011</option>
                <option value="2010" <?php echo (isset($_GET['year']) && $_GET['year'] == '2010') ? 'selected' : ''; ?>>2010</option>
                <option value="2009" <?php echo (isset($_GET['year']) && $_GET['year'] == '2009') ? 'selected' : ''; ?>>2009</option>
                <option value="2008" <?php echo (isset($_GET['year']) && $_GET['year'] == '2008') ? 'selected' : ''; ?>>2008</option>
                <option value="2007" <?php echo (isset($_GET['year']) && $_GET['year'] == '2007') ? 'selected' : ''; ?>>2007</option>
                <option value="2006" <?php echo (isset($_GET['year']) && $_GET['year'] == '2006') ? 'selected' : ''; ?>>2006</option>
                <option value="2005" <?php echo (isset($_GET['year']) && $_GET['year'] == '2005') ? 'selected' : ''; ?>>2005</option>
                <option value="2004" <?php echo (isset($_GET['year']) && $_GET['year'] == '2004') ? 'selected' : ''; ?>>2004</option>
                <option value="2003" <?php echo (isset($_GET['year']) && $_GET['year'] == '2003') ? 'selected' : ''; ?>>2003</option>
                <option value="2002" <?php echo (isset($_GET['year']) && $_GET['year'] == '2002') ? 'selected' : ''; ?>>2002</option>
                <option value="2001" <?php echo (isset($_GET['year']) && $_GET['year'] == '2001') ? 'selected' : ''; ?>>2001</option>
                <option value="2000" <?php echo (isset($_GET['year']) && $_GET['year'] == '2000') ? 'selected' : ''; ?>>2000</option>
            </select>

            <select name="price">
                <option value="">Select Price</option>
                <option value="0-50000" <?php echo (isset($_GET['price']) && $_GET['price'] == '0-50000') ? 'selected' : ''; ?>>0 - 50,000</option>
                <option value="50001-100000" <?php echo (isset($_GET['price']) && $_GET['price'] == '50001-100000') ? 'selected' : ''; ?>>50,001 - 100,000</option>
                <option value="100001-150000" <?php echo (isset($_GET['price']) && $_GET['price'] == '100001-150000') ? 'selected' : ''; ?>>100,001 - 150,000</option>
                <option value="150001-200000" <?php echo (isset($_GET['price']) && $_GET['price'] == '150001-200000') ? 'selected' : ''; ?>>150,001 - 200,000</option>
                <option value="200001-1000000" <?php echo (isset($_GET['price']) && $_GET['price'] == '200001-1000000') ? 'selected' : ''; ?>>200,001 and above</option>
            </select>
            <!-- <button type="reset">Reset</button> -->
        </div>
        </form>
    </div>

        <div class="product-container">
            <?php while ($row = $result->fetch_assoc()) {
                $imagePaths = explode(',', $row['image_paths']);
                $thumbnail = isset($imagePaths[0]) ? $imagePaths[0] : '';
                ?>
                <div class="product-card-container">
                    <div class="product-card">
                        <div class="price-tag">RM <?php echo $row['price']; ?></div>
                        <img src="<?php echo $thumbnail; ?>" alt="Car Image" class="product-image">
                        <h2><?php echo $row['brand_name'] . ' ' . $row['model_name'] . ' ' . $row['model_year']; ?></h2>
                        <hr />
                        <p><?php echo $row['specification']; ?></p>
                    </div>
                    <div class="booking-button">
                        <a href="user_booking.php?car_id=<?php echo $row['car_id']; ?>" class="explore-button">Explore More ></a>
                        <a href="payment.php?car_id=<?php echo $row['car_id']; ?>" class="book-button">Book Now</a>
                    </div>
                </div>
            <?php } ?>
        </div>

    </div>
    <!--footer-->
    <footer class="footer-section">
            <div class="footer-container">
                <div class="footer-cta pt-5 pb-5">
                    <div class="row">
                        <div class="col-xl-4 col-md-4 mb-30">
                            <div class="single-cta">
                                <i class="fas fa-map-marker-alt"></i>
                                <div class="cta-text">
                                    <h4>Find us</h4>
                                    <span> 80, Jalan Industri 2, Taman Seri Bayu, <br>14300 Nibong Tebal, Pulau Pinang</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-4 mb-30">
                            <div class="single-cta1">
                                <i class="fas fa-phone"></i>
                                <div class="cta-text">
                                    <h4>Call us</h4>
                                    <span>012-518 2468</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-4 mb-30">
                            <div class="single-cta2">
                                <i class="far fa-envelope-open"></i>
                                <div class="cta-text">
                                    <h4>Mail us</h4>
                                    <span>Khooi197671@gmail.com</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="footer-content pt-5 pb-5">
                    <div class="row2">
                        <div class="col-xl-4 col-lg-4 mb-50">
                            <div class="footer-widget">
                                <div class="footer-logo">
                                    <a href="#">Green Star Auto Enterprise</a>
                                </div>
                                <hr>
                                <div class="footer-text">
                                    <p>Our comprehensive used car booking website offers a seamless experience for users to browse a wide selection of reliable pre-owned vehicles,
                                    compare features and prices, read customer reviews, and conveniently book test drives or purchases, all through an intuitive and secure online platform.</p>
                                </div>
                                <div class="footer-social-icon">
                                    <span>Follow us</span>
                                    <a href="#"><i class="fab fa-facebook-f facebook-bg"></i></a>
                                    <a href="#"><i class="fab fa-twitter twitter-bg"></i></a>
                                    <a href="#"><i class="fab fa-instagram instagram-bg"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6 mb-30">
                            <div class="footer-widget">
                                <div class="footer-widget-heading">
                                    <h3>Useful Links</h3>
                                </div>
                                <ul>
                                    <li><a href="user_page.php">Home</a></li>
                                    <li><a href="aboutus.php">About us</a></li>
                                    <li><a href="product.php">Product</a></li>
                                    <li><a href="gallery.php">Gallery</a></li>                                         
                                    <li><a href="whatsapp://send?phone=+6011-24157828&">Contact us</a></li>
                
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6 mb-50">
                            <div class="footer-widget">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright-area">
                <div class="footer-container">
                    <div class="row3">
                        <div class="col-xl-6 col-lg-6 text-center text-lg-left">
                            <div class="copyright-text">
                                <p>Copyright &copy; 2024, All Right Reserved </p>
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6 d-none d-lg-block text-right">
                            <div class="footer-menu">
                                <ul>
                                    <li><a href="user_page.php">Home</a></li>
                                    <li><a href="#">Terms</a></li>
                                    <li><a href="#">Privacy</a></li>
                                    <li><a href="#">Policy</a></li>
                                    <li><a href="#">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</body>
<script>
document.getElementById('notificationLink').addEventListener('click', function (event) {
                // Prevent the default behavior of the link (e.g., navigating to the href)
                event.preventDefault();

                // Show an alert message
                alert("Please check your email!");
            });
</script>

</html>