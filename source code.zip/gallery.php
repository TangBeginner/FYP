<?php
session_start();
include 'config.php';

$errors = []; // Initialize error array

// Assuming user information is stored in session after login
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $query = "SELECT name FROM user WHERE id = $user_id";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        $user_name = $user['name'];
    } else {
        // Handle case where user data is not found
        $user_name = "";
    }
} else {
    // Redirect to login page if user is not logged in
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Gallery</title>
    <link rel="stylesheet" href="stylegallery.css">
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css">
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="">Green Star Auto Enterprise</a></div>
            <ul class="links">
                <li><a href="user_page.php">Home</a></li>
                <li><a href="aboutus.php">About</a></li>
                <li><a href="product.php">Product</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="my_booking.php">Order</a></li>
                <!-- <li><a href="user_booking.php"><i class="fa-solid fa-cart-shopping"></i> Order</a></li> -->
                <li><a href="logout.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i>
                        Log Out</a></li>
            </ul>
            <a href="userprofile.php" class="action_btn">User</a>
            <div class="toggle_btn">
                <i class="fa-solid fa-bars"></i>
            </div>

            <div class="dropdown_menu">
                <li><a href="">Home</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Product</a></li>
                <li><a href="">Gallery</a></li>
                <li><a href="">Login</a></li>
                <li><a href="" class="action_btn">User</a></li>
            </div>
        </nav>
    </header>
   


    <div class="statement">
        <h1>Feedback <br></h1>
        <span>given by our clients</span>
        <hr>
        
    </div>

    <?php
    // Fetch feedback from the database
    @include 'config.php';

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Modify the SQL query to filter out feedback with status 'Off'
    $result = $conn->query("SELECT feedback.*, user.name AS user_name FROM feedback JOIN user ON feedback.user_id = user.id WHERE feedback.status = 1 ORDER BY feedback.timestamp DESC");

    if ($result->num_rows > 0) {
        echo '<div class="owl-carousel owl-theme mt-5">';
        while ($row = $result->fetch_assoc()) {
            echo '<div class="owl-item">';
            echo '<div class="card">';
            echo '<div class="img-card">';
            echo "<img src='{$row['photo_path']}' alt='review' />";
            echo '</div>';
            echo '<div class="testimonial mt-4 mb-2">';
            echo "<blockquote>{$row['comment']}</blockquote>";
            echo '</div>';
            echo '<div class="name">';
            echo "{$row['user_name']}";
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';
    } else {
        echo "No feedback available.";
    }

    if (isset($_GET['feedback']) && $_GET['feedback'] == 'success') {
        echo '<script>alert("Feedback submitted successfully!");</script>';
    }
    $conn->close();
    ?>


<div class="feedback-container">
    <div class="left-container">
        
        <h2>Got a moment? Tell us about your experience.</h2>
        <p>Help us make a difference! Leave your comments and suggestions.</p>
    </div>
    <form action="submit_feedback.php" method="post" enctype="multipart/form-data" class="feedback-form">
        <label for="user_name">Name:</label>
        <input type="text" name="user_name" value="<?php echo htmlspecialchars($user_name); ?>" required>

        <label for="comment">Comment:</label>
        <textarea name="comment" required></textarea>

        <label for="photo">Photo:</label>
        <input type="file" name="photo" accept="image/*" required>

        <button type="submit">SUBMIT</button>
    </form>
</div>

  <!--footer-->
  <footer class="footer-section">
        <div class="footer-container">
            <div class="footer-cta pt-5 pb-5">
                <div class="row">
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta">
                            <i class="fas fa-map-marker-alt"></i>
                            <div class="cta-text">
                                <h4>Find us</h4>
                                <span> 80, Jalan Industri 2, Taman Seri Bayu, <br>14300 Nibong Tebal, Pulau Pinang</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta1">
                            <i class="fas fa-phone"></i>
                            <div class="cta-text">
                                <h4>Call us</h4>
                                <span>012-518 2468</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta2">
                            <i class="far fa-envelope-open"></i>
                            <div class="cta-text">
                                <h4>Mail us</h4>
                                <span>Khooi197671@gmail.com</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-content pt-5 pb-5">
                <div class="row2">
                    <div class="col-xl-4 col-lg-4 mb-50">
                        <div class="footer-widget">
                            <div class="footer-logo">
                                <a href="#">Green Star Auto Enterprise</a>
                            </div>
                            <hr>
                            <div class="footer-text">
                                <p>Our comprehensive used car booking website offers a seamless experience for users to browse a wide selection of reliable pre-owned vehicles,
                                compare features and prices, read customer reviews, and conveniently book test drives or purchases, all through an intuitive and secure online platform.</p>
                            </div>
                            <div class="footer-social-icon">
                                <span>Follow us</span>
                                <a href="#"><i class="fab fa-facebook-f facebook-bg"></i></a>
                                <a href="#"><i class="fab fa-twitter twitter-bg"></i></a>
                                <a href="#"><i class="fab fa-instagram instagram-bg"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-30">
                        <div class="footer-widget">
                            <div class="footer-widget-heading">
                                <h3>Useful Links</h3>
                            </div>
                            <ul>
                                <li><a href="user_page.php">Home</a></li>
                                <li><a href="aboutus.php">About us</a></li>
                                <li><a href="product.php">Product</a></li>
                                <li><a href="gallery.php">Gallery</a></li>                                         
                                <li><a href="whatsapp://send?phone=+6011-24157828&">Contact us</a></li>
               
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-50">
                        <div class="footer-widget">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-area">
            <div class="footer-container">
                <div class="row3">
                    <div class="col-xl-6 col-lg-6 text-center text-lg-left">
                        <div class="copyright-text">
                            <p>Copyright &copy; 2024, All Right Reserved </p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 d-none d-lg-block text-right">
                        <div class="footer-menu">
                            <ul>
                                <li><a href="user_page.php">Home</a></li>
                                <li><a href="#">Terms</a></li>
                                <li><a href="#">Privacy</a></li>
                                <li><a href="#">Policy</a></li>
                                <li><a href="#">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

</body>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/owl.carousel.js"></script>
<script>

    document.addEventListener('DOMContentLoaded', function () {
        //------------------------logout confirmation
        function logoutConfirmation() {
            var logoutConfirmed = confirm("Are you sure you want to log out?");
            if (logoutConfirmed) {
                // Redirect to the logout page
                window.location.href = "login.php";
            }
        }
        document.getElementById('notificationLink').addEventListener('click', function (event) {
            // Prevent the default behavior of the link (e.g., navigating to the href)
            event.preventDefault();

            // Show an alert message
            alert("Please check your email!");
        });
    });

    $(document).ready(function () {
        var slider = $(".owl-carousel");
        slider.owlCarousel({
            autoplay: true,
            autoplayTimeout: 5000,
            autoplayHoverPause: false,
            items: 1,
            stagePadding: 20,
            center: true,
            nav: false,
            margin: 20,
            dots: true,
            loop: true,
            responsive: {
                0: { items: 1 },
                480: { items: 2 },
                575: { items: 2 },
                768: { items: 2 },
                991: { items: 3 },
                1200: { items: 4 }
            }
        });
    });

   
</script>

</html>