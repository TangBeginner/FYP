<?php
// Include database connection
include 'config.php';

// Check if payment_id is set and valid
if (isset($_POST['payment_id']) && is_numeric($_POST['payment_id'])) {
    $paymentId = $_POST['payment_id'];

    // Update transaction status to 'done' for the given payment ID
    $updateQuery = "UPDATE payments SET transaction_status = 'done' WHERE payment_id = $paymentId";
    $conn->query($updateQuery);
}
?>
