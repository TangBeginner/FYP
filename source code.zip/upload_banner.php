<?php
// Include database connection
@include 'config.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle file upload
    $target_directory = "uploads/";
    $target_file = $target_directory . basename($_FILES["banner_image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["banner_image"]["tmp_name"]);
    if ($check !== false) {
        // Upload the file
        if (move_uploaded_file($_FILES["banner_image"]["tmp_name"], $target_file)) {
            // Store image path in the database
            $image_path = $target_file;
            $sql = "INSERT INTO banners (image) VALUES ('$image_path')";
            if (mysqli_query($conn, $sql)) {
                echo "<script>alert('Banner uploaded successfully.'); window.location.href = 'admin_page.php';</script>";
            } else {
                echo "<script>alert('Error uploading banner.'); window.location.href = 'admin_page.php';</script>";
            }
        } else {
            echo "<script>alert('Sorry, there was an error uploading your file.'); window.location.href = 'admin_page.php';</script>";
        }
    } else {
        echo "<script>alert('File is not an image.'); window.location.href = 'admin_page.php';</script>";
    }
} else {
    echo "<script>alert('Form not submitted.'); window.location.href = 'admin_page.php';</script>";
}

// Close database connection
mysqli_close($conn);
?>