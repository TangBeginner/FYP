<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styleFeedback.css">
    <title>Admin Feedback Management</title>
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>

<body>

    <div class="sidebar">
        <nav>
            <div class="logo">
                <a href="#"><span><img src="logo.jpg"></span></a>
            </div>
            <ul>
                <li><a href="admin_page.php"><i class="fa-solid fa-house"></i> Home</a></li>
                <li><a href="admin_verify.php"><i class="fa-solid fa-user"></i> User management</a></li>
                <li><a href="productmanagement.php"><i class="fa-solid fa-car"></i> Product</a></li>
                <li><a href="admin_order.php"><i class="fa-regular fa-file-lines"></i> Booking</a></li>
                <li><a href="notification.php"><i class="fa-solid fa-bell"></i> Notification</a></li>
                <li class="active"><a href="feedback.php"><i class="fa-regular fa-comment"></i> Feedback</a></li>
                <li><a href="login.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i>
                        Log Out</a></li>
            </ul>
        </nav>
    </div>


    <main>
        <!-- <h2>Feedback Management</h2> -->

        <?php
        @include 'config.php';

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $result = $conn->query("SELECT feedback.*, user.name AS user_name, feedback.status FROM feedback JOIN user ON feedback.user_id = user.id ORDER BY feedback.timestamp DESC");
        if ($result->num_rows > 0) {
            echo '<table class="feedback-table">';
            echo '<thead>';
            echo '<tr>';
            echo '<th>User</th>';
            echo '<th>Date</th>';
            echo '<th>Comment</th>';
            echo '<th>Photo</th>';
            echo '<th>Status</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';
            while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . $row['user_name'] . '</td>';
                echo '<td>' . $row['timestamp'] . '</td>';
                echo '<td>' . $row['comment'] . '</td>';
                echo '<td><img src="' . $row['photo_path'] . '" alt="review" style="max-width: 100px; max-height: 100px;"></td>';
                // Check if 'status' key exists in the $row array before accessing it
                $status = isset($row['status']) ? $row['status'] : 0;
                echo '<td><button class="status-btn" data-id="' . $row['id'] . '" data-status="' . $status . '">' . ($status == 1 ? 'On' : 'Off') . '</button></td>';
                echo '</tr>';
            }
            echo '</tbody>';
            echo '</table>';
        } else {
            echo "<p>No feedback available.</p>";
        }

        $conn->close();
        ?>
    </main>

   
</body>

<script>
    $(document).ready(function () {
        // Attach a click event handler to the status buttons
        $('.status-btn').click(function () {
            // Get the feedback id and status from the button's data attributes
            var feedbackId = $(this).data('id');
            var currentStatus = $(this).data('status');

            // Toggle the status (1 to 0, and 0 to 1)
            var newStatus = currentStatus === 1 ? 0 : 1;

            // Reference to the button element
            var button = $(this);

            // Send an AJAX request to update the feedback status in the database
            $.ajax({
                type: 'POST',
                url: 'feedback_status.php', // Replace with the actual file to handle the update
                data: {
                    feedbackId: feedbackId,
                    newStatus: newStatus
                },
                success: function (response) {
                    // Update the button text and data-status attribute based on the new status
                    button.data('status', newStatus);
                    button.text(newStatus === 1 ? 'On' : 'Off');

                    // Toggle the 'active' class to change the button style
                    if (newStatus === 1) {
                        button.addClass('active').css('background-color', '#029ca3');
                    } else {
                        button.removeClass('active').css('background-color', '#d96c5b');
                    }

                    // Force a reflow to apply the style changes immediately
                    button[0].offsetHeight;

                },
                error: function (error) {
                    console.error('Error updating feedback status:', error);
                }
            });
        });
    });
</script>




</html>