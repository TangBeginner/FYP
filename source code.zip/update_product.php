<?php
// Include configuration and start session
@include 'config.php';
session_start();

if (!isset($_SESSION['admin_name'])) {
    header('location:login_form.php');
    exit;
}

// Verify the database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if required fields are set
    if (isset($_POST['model_id']) && isset($_POST['body_type_id']) && isset($_POST['price']) && isset($_POST['specification'])) {
        // Sanitize inputs
        $model_id = $_POST['model_id'];
        $body_type_id = $_POST['body_type_id'];
        $price = $_POST['price'];
        $specification = $_POST['specification'];

        // Update product details
        $updateQuery = "UPDATE car SET body_type_id = ?, price = ?, specification = ? WHERE model_id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("idsi", $body_type_id, $price, $specification, $model_id);

        // Check if the update was successful
        if ($stmt->execute()) {
         
            // Prepare delete query for car_image
$deleteImageQuery = "DELETE FROM car_image WHERE car_id = ? AND image_path = ?";
$deleteStmt = $conn->prepare($deleteImageQuery);

// Check if the statement was prepared correctly
if (!$deleteStmt) {
    echo "Error preparing delete statement: " . $conn->error . "<br>";
} else {
    foreach ($deletedImagesArray as $imagePath) {
        // Trim the image path
        $imagePath = trim($imagePath);

        // Bind parameters and execute the statement
        $deleteStmt->bind_param("is", $model_id, $imagePath);
        
        // Execute the statement and check for errors
        if ($deleteStmt->execute()) {
            if ($deleteStmt->affected_rows > 0) {
                // File path for deletion
                $filePath = $imagePath;
                
                // Delete the image file from the file system
                if (file_exists($filePath)) {
                    if (unlink($filePath)) {
                        echo "Deleted image from file system: $filePath<br>";
                    } else {
                        echo "Error deleting image from file system: $filePath<br>";
                    }
                }
                echo "Deleted image from database: $imagePath<br>";
            } else {
                echo "No rows affected for $imagePath.<br>";
            }
        } else {
            echo "Error deleting image from database: " . $deleteStmt->error . "<br>";
        }
    }

    // Close the delete statement
    $deleteStmt->close();
}



            // Upload new images if provided
            if (!empty($_FILES['new_images']['name'][0])) {
                $targetDir = "uploads/";
                foreach ($_FILES['new_images']['name'] as $key => $imageName) {
                    if ($_FILES['new_images']['error'][$key] === UPLOAD_ERR_OK) {
                        $targetFile = $targetDir . basename($imageName);
                        if (move_uploaded_file($_FILES['new_images']['tmp_name'][$key], $targetFile)) {
                            // Insert new image path in the database
                            $insertImageQuery = "INSERT INTO car_image (car_id, image_path) VALUES (?, ?)";
                            $insertStmt = $conn->prepare($insertImageQuery);
                            $insertStmt->bind_param("is", $model_id, $targetFile);
                            $insertStmt->execute();
                            // Close the insert statement
                            $insertStmt->close();
                        } else {
                            echo "Error uploading file: $imageName";
                        }
                    }
                }
            }

            echo "Product updated successfully.";
        } else {
            echo "Error updating product: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Required fields missing.";
    }
}

// Close the database connection
$conn->close();
?>
