<?php
// Include configuration and start session
@include 'config.php';
session_start();

if (!isset($_SESSION['admin_name'])) {
    header('location:login_form.php');
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the car should be activated
if (isset($_GET['activate']) && !empty($_GET['activate'])) {
    $carId = $_GET['activate'];
    $updateQuery = "UPDATE car SET status = 'available' WHERE car_id = '$carId'";
    if ($conn->query($updateQuery) === TRUE) {
        echo "<script>alert('Car reactivated successfully');</script>";
    } else {
        echo "<script>alert('Error updating record: " . $conn->error . "');</script>";
    }
}

// Fetch the list of cars from the database
$carsQuery = "SELECT car.*, model.name as model_name, model.year as model_year, brand.name as brand_name, body_type.type as body_type_name
              FROM car
              JOIN model ON car.model_id = model.model_id
              JOIN brand ON model.brand_id = brand.brand_id
              JOIN body_type ON car.body_type_id = body_type.body_type_id";

// Check if a search query is submitted
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = $conn->real_escape_string($_GET['search']);
    $carsQuery .= " WHERE brand.name LIKE '%$searchTerm%' OR model.name LIKE '%$searchTerm%' OR model.year LIKE '%$searchTerm%'";
}

$result = $conn->query($carsQuery);

if (!$result) {
    die("Query failed: " . $conn->error);
}
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management</title>
    <link rel="stylesheet" href="styleAdmin.css">
    <script src="https://kit.fontawesome.com/7813dbc7de.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <style>
        .status-available {
            color: green;
        }

        .status-booked {
            color: red;
        }

        .btn.activate-btn {
            font-size: 17px;
            width: 78px;
            text-align: center;
            padding: 10px;
            background-color: #9284b4;
            color: white;
        }
    </style>
</head>

<body>

    <div class="sidebar">
        <nav>
            <div class="logo">
                <a href="#"><span><img src="logo.jpg"></span></a>
            </div>
            <ul>
                <li><a href="admin_page.php"><i class="fa-solid fa-house"></i> Home</a></li>
                <li><a href="admin_verify.php"><i class="fa-solid fa-user"></i> User management</a></li>
                <li class="active"><a href="productmanagement.php"><i class="fa-solid fa-car"></i> Product</a></li>
                <li><a href="admin_order.php"><i class="fa-regular fa-file-lines"></i> Booking</a></li>
                <li><a href="notification.php"><i class="fa-solid fa-bell"></i> Notification</a></li>
                <li><a href="feedback.php"><i class="fa-regular fa-comment"></i> Feedback</a></li>
                <li><a href="login.php" onclick="logoutConfirmation()"><i class="fa-solid fa-right-from-bracket"></i>
                        Log Out</a></li>
            </ul>
        </nav>
    </div>

    <div class="product-content">
        <!-- Add button at the right-top side of the table -->
        <h3>Product Management</h3>
        <div class="action-bar">
            <div class="search-bar">
                <form method="GET" action="productmanagement.php">
                    <input type="text" name="search" placeholder="Search by brand or model...">
                    <button type="submit">Search</button>
                </form>
            </div>

            <a href="add_product.php" class="add-btn">Add Product</a>
        </div>

        <!-- Table to view the product list -->
        <table class="product-table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Brand</th>
                    <th>Model</th>
                    <th>Type</th>
                    <th>Price(RM)</th>
                    <th>Specification</th>
                    <th>Image</th>
                  
                    <th>Action</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php
                // Loop the result set and display car
                if ($result->num_rows > 0) {
                    $counter = 1;
                    while ($row = $result->fetch_assoc()) {
                        $statusClass = ($row['status'] == 'available') ? 'status-available' : 'status-booked';
                        echo "<tr>
                           <td>{$counter}</td>
                        <td>{$row['brand_name']}</td>
                        <td>{$row['model_name']} ({$row['model_year']})</td>
                        <td>{$row['body_type_name']}</td>
                        <td>{$row['price']}</td>
                        <td>{$row['specification']}</td>
                        <td>";
                        // Display each image associated with the car
                        $imagePaths = explode(',', $row['image_paths']);
                        foreach ($imagePaths as $imagePath) {
                            $imagePath = trim($imagePath); 
                            if (!empty ($imagePath)) {
                                echo "<img src='{$imagePath}' alt='Car Image' style='width: 150px; height: auto;'>";
                            }
                        }
                        echo "</td>
                       
                        <td>
                            <a href='deleteproduct.php?model_id={$row['model_id']}' class='btn delete-btn' onclick=\"return confirm('Are you sure you want to delete this product?')\">
                                Delete
                            </a>                    
                            <a href='edit_product.php?model_id={$row['model_id']}' class='btn edit-btn'>Edit</a>";
                            if ($row['status'] == 'booked') {
                                echo "<a href='productmanagement.php?activate={$row['car_id']}' class='btn activate-btn' onclick=\"return confirm('Are you sure you want to activate this product?')\">Activate</a>";
                            }
                        echo "</td>

                         <td class='{$statusClass}'>" . ucfirst($row['status']) . "</td>
                    </tr>";
                        $counter++;
                    }
                } else {
                    echo "<tr><td colspan='9'>No products found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

</body>

</html>
