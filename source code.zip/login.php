<?php
@include 'config.php';
session_start();

if (isset($_POST['submit'])) {
    // Verify reCAPTCHA
    $recaptcha_secret = "6Ld3c0YpAAAAAB6mJdWMqh1XnKwZ9H7__gVWMgDl";
    $recaptcha_response = $_POST['g-recaptcha-response'];
    $verify_url = "https://www.google.com/recaptcha/api/siteverify";
    $data = [
        'secret' => $recaptcha_secret,
        'response' => $recaptcha_response,
    ];
    $options = [
        'http' => [
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data),
        ],
    ];
    $context = stream_context_create($options);
    $result = file_get_contents($verify_url, false, $context);

    $decoded_result = json_decode($result, true);
    if (!$decoded_result['success']) {
        $error[] = 'reCAPTCHA verification failed!';
    } else {
        // Continue with the login logic
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = $_POST['password'];

        // Check if the user exists
        $select = "SELECT * FROM user WHERE email = '$email' AND verify = 1";
        $result = mysqli_query($conn, $select);

        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_array($result);
            $stored_password = $row['password'];
            
            // Check if the stored password is MD5
            if (strlen($stored_password) == 32 && ctype_xdigit($stored_password)) {
                // Verify MD5 password
                if (md5($password) === $stored_password) {
                    // Rehash with new algorithm
                    $new_hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $update = "UPDATE user SET password = '$new_hashed_password' WHERE email = '$email'";
                    mysqli_query($conn, $update);

                    // Log the user in
                    $_SESSION['user_id'] = $row['id'];
                    if ($row['user_type'] == 'admin') {
                        $_SESSION['admin_name'] = $row['name'];
                        header('Location: admin_page.php');
                    } else if ($row['user_type'] == 'user') {
                        $_SESSION['user_name'] = $row['name'];
                        header('Location: user_page.php');
                    }
                } else {
                    $error[] = 'Incorrect email or password or account not verified!';
                }
            } else {
                // Verify new hashed password
                if (password_verify($password, $stored_password)) {
                    // Log the user in
                    $_SESSION['user_id'] = $row['id'];
                    if ($row['user_type'] == 'admin') {
                        $_SESSION['admin_name'] = $row['name'];
                        header('Location: admin_page.php');
                    } else if ($row['user_type'] == 'user') {
                        $_SESSION['user_name'] = $row['name'];
                        header('Location: user_page.php');
                    }
                } else {
                    $error[] = 'Incorrect email or password or account not verified!';
                }
            }
        } else {
            $error[] = 'Incorrect email or password or account not verified!';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
          integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body>
<header>
    <nav class="navbar">
        <div class="logo"><a href="">Green Star Auto Enterprise</a></div>
    </nav>
</header>
<div class="form-container">
    <form action="login.php" method="post">
        <h2>Green Star Auto Enterprise</h2>
        <h3>Login now</h3>
        <?php
        if (isset($error)) {
            foreach ($error as $err) {
                echo '<span class="error-msg">' . $err . '</span>';
            }
        }
        ?>
        <input type="email" name="email" required placeholder="Enter your email">
        <input type="password" name="password" required placeholder="Enter your password">
        <div class="g-recaptcha" data-sitekey="6Ld3c0YpAAAAAEn5uYuITEQMkz5VveZsNFf-4WVh"></div>
        <input type="submit" name="submit" value="Login" class="form-btn">
        <p>No account? <a href="register.php">Register now</a></p>
    </form>
</div>
</body>
</html>
